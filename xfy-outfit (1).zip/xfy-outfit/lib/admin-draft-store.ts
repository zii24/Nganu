import type { Product } from "./types";

const KEY = "xfy_admin_draft_products";

function readAll(): Product[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function writeAll(products: Product[]) {
  try {
    window.localStorage.setItem(KEY, JSON.stringify(products));
  } catch {
    // ignore quota / privacy-mode errors
  }
}

export function addDraftProduct(product: Product) {
  const all = readAll();
  writeAll([product, ...all]);
}

export function getDraftProducts(): Product[] {
  return readAll();
}
