import type { ShippingRegion } from "./types";

// Editable mock rates. In production this becomes an admin-managed table
// (see /admin/shipping) backed by a real courier-rate or flat-rate API.
// Figures here are configurable estimates, not guaranteed courier rates.
export const SHIPPING_REGIONS: ShippingRegion[] = [
  { id: "id", name: "Indonesia", enabled: true, feeIdr: 25000, feeUsd: 2, minDays: 1, maxDays: 3 },
  { id: "my", name: "Malaysia", enabled: true, feeIdr: 145000, feeUsd: 10, minDays: 4, maxDays: 7 },
  { id: "sg", name: "Singapore", enabled: true, feeIdr: 135000, feeUsd: 9, minDays: 3, maxDays: 6 },
  { id: "th", name: "Thailand", enabled: true, feeIdr: 150000, feeUsd: 10, minDays: 4, maxDays: 7 },
  { id: "vn", name: "Vietnam", enabled: true, feeIdr: 155000, feeUsd: 10, minDays: 4, maxDays: 8 },
  { id: "ph", name: "Philippines", enabled: true, feeIdr: 150000, feeUsd: 10, minDays: 4, maxDays: 8 },
  { id: "hk", name: "Hong Kong", enabled: true, feeIdr: 175000, feeUsd: 12, minDays: 4, maxDays: 7 },
  { id: "jp", name: "Japan", enabled: true, feeIdr: 220000, feeUsd: 15, minDays: 5, maxDays: 9 },
  { id: "kr", name: "South Korea", enabled: true, feeIdr: 220000, feeUsd: 15, minDays: 5, maxDays: 9 },
  { id: "anz", name: "Australia / New Zealand", enabled: true, feeIdr: 260000, feeUsd: 17, minDays: 6, maxDays: 10 },
  { id: "us", name: "United States", enabled: true, feeIdr: 320000, feeUsd: 21, minDays: 7, maxDays: 14 },
  { id: "ca", name: "Canada", enabled: true, feeIdr: 330000, feeUsd: 22, minDays: 7, maxDays: 14 },
  { id: "uk", name: "United Kingdom", enabled: true, feeIdr: 300000, feeUsd: 20, minDays: 6, maxDays: 12 },
  { id: "eu", name: "Europe", enabled: true, feeIdr: 300000, feeUsd: 20, minDays: 6, maxDays: 12 },
];

export function getEnabledRegions() {
  return SHIPPING_REGIONS.filter((r) => r.enabled);
}

export function getRegionById(id: string) {
  return SHIPPING_REGIONS.find((r) => r.id === id);
}
