import type { Order, OrderStatus } from "./types";
import { PRODUCTS } from "./mock-data";

function hoursAgo(h: number) {
  return new Date(Date.now() - h * 60 * 60 * 1000).toISOString();
}
function daysAgo(d: number) {
  return hoursAgo(d * 24);
}

const FULL_TIMELINE: OrderStatus[] = [
  "Order Confirmed",
  "Waiting for Seller",
  "Product Being Reviewed",
  "Quality Check Completed",
  "Preparing Shipment",
  "Shipped",
  "Delivered",
  "Completed",
];

function buildTimeline(reachedIndex: number, startedDaysAgo: number, issue = false) {
  const events = FULL_TIMELINE.slice(0, reachedIndex + 1).map((status, i) => ({
    status,
    timestamp: daysAgo(startedDaysAgo - i * 1.1),
  }));
  if (issue) {
    events.push({
      status: "Inspection Issue" as OrderStatus,
      timestamp: daysAgo(startedDaysAgo - (reachedIndex + 1) * 1.1),
    });
  }
  return events;
}

const p = (slug: string) => PRODUCTS.find((x) => x.slug === slug)!;

export const ORDERS: Order[] = [
  {
    id: "XFY-20260918-0142",
    items: [
      {
        productId: p("champion-reverse-weave-hoodie-grey").id,
        name: p("champion-reverse-weave-hoodie-grey").name,
        slug: p("champion-reverse-weave-hoodie-grey").slug,
        image: p("champion-reverse-weave-hoodie-grey").images[0].url,
        priceIdr: p("champion-reverse-weave-hoodie-grey").priceIdr,
        priceUsd: p("champion-reverse-weave-hoodie-grey").priceUsd,
        size: "L",
        quantity: 1,
      },
    ],
    status: "Shipped",
    timeline: buildTimeline(5, 6),
    shippingRegionId: "id",
    shippingFeeIdr: 25000,
    shippingFeeUsd: 2,
    totalIdr: 475000,
    totalUsd: 31,
    createdAt: daysAgo(6),
  },
  {
    id: "XFY-20260910-0098",
    items: [
      {
        productId: p("levis-501-original-jeans-indigo").id,
        name: p("levis-501-original-jeans-indigo").name,
        slug: p("levis-501-original-jeans-indigo").slug,
        image: p("levis-501-original-jeans-indigo").images[0].url,
        priceIdr: p("levis-501-original-jeans-indigo").priceIdr,
        priceUsd: p("levis-501-original-jeans-indigo").priceUsd,
        size: "32x32",
        quantity: 1,
      },
    ],
    status: "Completed",
    timeline: buildTimeline(7, 14),
    shippingRegionId: "id",
    shippingFeeIdr: 25000,
    shippingFeeUsd: 2,
    totalIdr: 445000,
    totalUsd: 29,
    createdAt: daysAgo(14),
    deliveredAt: daysAgo(9),
    review: {
      rating: 5,
      comment: "Exactly as described, condition notes were spot on. Fast dispatch from XFY.",
    },
  },
  {
    id: "XFY-20260921-0176",
    items: [
      {
        productId: p("ralph-lauren-oxford-shirt-light-blue").id,
        name: p("ralph-lauren-oxford-shirt-light-blue").name,
        slug: p("ralph-lauren-oxford-shirt-light-blue").slug,
        image: p("ralph-lauren-oxford-shirt-light-blue").images[0].url,
        priceIdr: p("ralph-lauren-oxford-shirt-light-blue").priceIdr,
        priceUsd: p("ralph-lauren-oxford-shirt-light-blue").priceUsd,
        size: "M",
        quantity: 1,
      },
    ],
    status: "Product Being Reviewed",
    timeline: buildTimeline(2, 2),
    shippingRegionId: "sg",
    shippingFeeIdr: 135000,
    shippingFeeUsd: 9,
    totalIdr: 515000,
    totalUsd: 34,
    createdAt: daysAgo(2),
  },
  {
    id: "XFY-20260905-0061",
    items: [
      {
        productId: p("dickies-874-work-pants-olive").id,
        name: p("dickies-874-work-pants-olive").name,
        slug: p("dickies-874-work-pants-olive").slug,
        image: p("dickies-874-work-pants-olive").images[0].url,
        priceIdr: p("dickies-874-work-pants-olive").priceIdr,
        priceUsd: p("dickies-874-work-pants-olive").priceUsd,
        size: "32",
        quantity: 1,
      },
    ],
    status: "Inspection Issue",
    timeline: buildTimeline(2, 9, true),
    shippingRegionId: "id",
    shippingFeeIdr: 25000,
    shippingFeeUsd: 2,
    totalIdr: 305000,
    totalUsd: 20,
    createdAt: daysAgo(9),
    inspectionNotes:
      "Item received differs slightly from listing photos (additional fading on rear pocket not previously disclosed). XFY team is reviewing before proceeding — buyer will be offered a partial refund, replacement item, or full cancellation.",
  },
];

export function getOrderById(id: string) {
  return ORDERS.find((o) => o.id === id);
}
