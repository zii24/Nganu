import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import type { Currency, Product } from "./types";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** Format a price already stored in the given currency. Never auto-converts. */
export function formatPrice(product: Pick<Product, "priceIdr" | "priceUsd">, currency: Currency) {
  return formatAmount(currency === "IDR" ? product.priceIdr : product.priceUsd, currency);
}

export function formatAmount(amount: number, currency: Currency) {
  if (currency === "IDR") {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      maximumFractionDigits: 0,
    }).format(amount);
  }
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(amount);
}

const NEW_DROP_WINDOW_MS = 72 * 60 * 60 * 1000;

export function isNewDrop(publishedAt: string, now: Date = new Date()) {
  const published = new Date(publishedAt).getTime();
  return now.getTime() - published <= NEW_DROP_WINDOW_MS && now.getTime() >= published;
}

export function isPurchasable(status: Product["inventoryStatus"]) {
  return status === "Published";
}

export function formatDate(iso: string, locale: "en" | "id" = "en") {
  return new Date(iso).toLocaleDateString(locale === "id" ? "id-ID" : "en-US", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export function formatDateTime(iso: string, locale: "en" | "id" = "en") {
  return new Date(iso).toLocaleString(locale === "id" ? "id-ID" : "en-US", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function slugify(input: string) {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}
