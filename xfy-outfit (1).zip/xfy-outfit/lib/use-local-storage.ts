"use client";

import { useEffect, useState, useCallback } from "react";

/**
 * A small localStorage-backed useState. Safe for SSR: starts with the
 * fallback value on the server and first client render, then hydrates
 * from storage in an effect to avoid hydration mismatches.
 */
export function useLocalStorage<T>(key: string, initialValue: T) {
  const [value, setValue] = useState<T>(initialValue);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(key);
      if (raw) setValue(JSON.parse(raw));
    } catch {
      // ignore malformed storage
    } finally {
      setHydrated(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  const update = useCallback(
    (next: T | ((prev: T) => T)) => {
      setValue((prev) => {
        const resolved = typeof next === "function" ? (next as (prev: T) => T)(prev) : next;
        try {
          window.localStorage.setItem(key, JSON.stringify(resolved));
        } catch {
          // storage unavailable (private mode, quota) — fail silently
        }
        return resolved;
      });
    },
    [key]
  );

  return [value, update, hydrated] as const;
}
