import type { Offer } from "./types";
import { PRODUCTS } from "./mock-data";

function hoursAgo(h: number) {
  return new Date(Date.now() - h * 60 * 60 * 1000).toISOString();
}

const p = (slug: string) => PRODUCTS.find((x) => x.slug === slug)!;

export const OFFERS: Offer[] = [
  {
    id: "OFR-1001",
    productId: p("carhartt-wip-detroit-jacket-brown").id,
    offerIdr: 1100000,
    offerUsd: 71,
    status: "Pending Review",
    createdAt: hoursAgo(4),
    expiresAt: hoursAgo(4 - 24),
  },
  {
    id: "OFR-1002",
    productId: p("levis-501-original-jeans-indigo").id,
    offerIdr: 360000,
    offerUsd: 24,
    status: "Accepted",
    createdAt: hoursAgo(30),
    expiresAt: hoursAgo(6),
  },
  {
    id: "OFR-1003",
    productId: p("ralph-lauren-oxford-shirt-light-blue").id,
    offerIdr: 300000,
    offerUsd: 19,
    status: "Auto-Rejected",
    createdAt: hoursAgo(10),
    expiresAt: hoursAgo(-14),
  },
  {
    id: "OFR-1004",
    productId: p("dickies-874-work-pants-olive").id,
    offerIdr: 240000,
    offerUsd: 16,
    status: "Countered",
    createdAt: hoursAgo(18),
    expiresAt: hoursAgo(-6),
    counterIdr: 260000,
    counterUsd: 17,
  },
  {
    id: "OFR-1005",
    productId: p("champion-reverse-weave-hoodie-grey").id,
    offerIdr: 400000,
    offerUsd: 26,
    status: "Expired",
    createdAt: hoursAgo(50),
    expiresAt: hoursAgo(26),
  },
];
