export interface JournalArticle {
  slug: string;
  title: string;
  excerpt: string;
  category: string;
  cover: string;
  publishedAt: string;
  body: string[];
}

export const JOURNAL_ARTICLES: JournalArticle[] = [
  {
    slug: "how-xfy-grades-condition",
    title: "Inside the XFY Inspection Room",
    excerpt: "What actually happens between a seller dropping off a piece and it landing in your cart — and why we never round a condition score up.",
    category: "Process",
    cover: "https://picsum.photos/seed/xfy-journal-inspection/1200/800",
    publishedAt: "2026-09-14T00:00:00.000Z",
    body: [
      "Every item that reaches XFY passes through the same inspection room before it's listed. We photograph it under consistent lighting, take it through a fixed checklist, and score it against our 1–10 scale — not against what we hope it sells for.",
      "The goal isn't to make everything look like a 9. A honest 7 with clear notes builds more trust — and more repeat buyers — than an optimistic 9 that disappoints on arrival.",
      "We also measure by hand rather than relying on the size printed on the tag, since sizing has shifted across decades and brands. It takes longer, but it's the difference between a piece that fits and one that gets returned.",
    ],
  },
  {
    slug: "hidden-gems-bandung",
    title: "Hidden Gems: Sourcing From Bandung's Back Alleys",
    excerpt: "The city's thrift networks run deeper than its famous factory outlets. A look at where our team actually finds pieces worth curating.",
    category: "Hidden Gems",
    cover: "https://picsum.photos/seed/xfy-journal-bandung/1200/800",
    publishedAt: "2026-09-08T00:00:00.000Z",
    body: [
      "Bandung's reputation for thrift runs on its factory outlet strips, but the pieces that actually make it onto XFY rarely come from there. They come from smaller, rotating markets that change stock weekly and reward showing up early.",
      "Our sourcing team builds relationships with individual sellers over months, not single visits — the good stock rarely hits the table where anyone can see it first.",
    ],
  },
  {
    slug: "reading-a-carhartt-tag",
    title: "How to Read a Carhartt Tag Like You Mean It",
    excerpt: "Union labels, RN numbers, and the small print details that tell you more about an item's era than the size on the label ever will.",
    category: "Guides",
    cover: "https://picsum.photos/seed/xfy-journal-carhartt/1200/800",
    publishedAt: "2026-08-27T00:00:00.000Z",
    body: [
      "The inside tag on a piece of workwear carries more information than most buyers realize — union label placement, RN numbers, and font changes all shift across production eras.",
      "It's a small detail, but it's part of why our team photographs tags separately in every listing gallery: context matters as much as condition.",
    ],
  },
  {
    slug: "why-measurements-matter-more-than-size-tags",
    title: "Why We Measure Everything by Hand",
    excerpt: "A size Large from three different decades can fit three completely different ways. Here's how we account for that on every listing.",
    category: "Guides",
    cover: "https://picsum.photos/seed/xfy-journal-measurements/1200/800",
    publishedAt: "2026-08-15T00:00:00.000Z",
    body: [
      "Vintage and pre-owned sizing drifts. A tag that says Large from one era can measure closer to a modern Medium, and brand-to-brand variance makes it worse.",
      "That's the reasoning behind recording chest, shoulder, sleeve, and length measurements on every applicable listing — so you're buying based on how a piece actually fits, not what the tag claims.",
    ],
  },
];

export function getArticleBySlug(slug: string) {
  return JOURNAL_ARTICLES.find((a) => a.slug === slug);
}
