import type { Order } from "./types";

const KEY = "xfy_orders";

function readAll(): Record<string, Order> {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function writeAll(orders: Record<string, Order>) {
  try {
    window.localStorage.setItem(KEY, JSON.stringify(orders));
  } catch {
    // ignore quota / privacy-mode errors
  }
}

export function saveOrder(order: Order) {
  const all = readAll();
  all[order.id] = order;
  writeAll(all);
}

export function getStoredOrder(id: string): Order | undefined {
  return readAll()[id];
}

export function getAllStoredOrders(): Order[] {
  return Object.values(readAll());
}

export function generateOrderId() {
  const now = new Date();
  const stamp = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, "0")}${String(now.getDate()).padStart(2, "0")}`;
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `XFY-${stamp}-${rand}`;
}
