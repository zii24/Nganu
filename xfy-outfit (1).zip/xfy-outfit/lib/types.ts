// Core domain types for XFY Outfit.
// Kept backend-agnostic on purpose: these shapes are what a future API
// (e.g. a Xendit-backed Next.js route or external service) should return.

export type Category =
  | "T-Shirts"
  | "Long Sleeve"
  | "Shirts"
  | "Hoodies"
  | "Sweatshirts"
  | "Jackets"
  | "Knitwear"
  | "Pants"
  | "Jeans"
  | "Shorts"
  | "Accessories";

export type ConditionScore = 6 | 7 | 8 | 9 | 10;

export const CONDITION_LABEL: Record<ConditionScore, string> = {
  10: "Like New",
  9: "Excellent",
  8: "Very Good",
  7: "Good",
  6: "Fair",
};

export type AuthenticityStatus = "Original" | "Not Verified" | "Not Original";

export type InventoryStatus =
  | "Draft"
  | "Published"
  | "Checkout in Progress"
  | "Reserved"
  | "Sold"
  | "Archived";

export interface Measurements {
  length?: number;
  width?: number;
  chestWidth?: number;
  shoulder?: number;
  sleeve?: number;
  waist?: number;
  rise?: number;
  inseam?: number;
  legOpening?: number;
}

export type ImageKind = "front" | "back" | "tag" | "wash_tag" | "detail" | "defect";

export interface ProductImage {
  url: string;
  kind: ImageKind;
  alt: string;
}

export interface Product {
  id: string;
  slug: string;
  name: string;
  brand: string;
  category: Category;
  descriptionEn: string;
  descriptionId: string;
  priceIdr: number;
  priceUsd: number;
  /** Hidden from buyers. Never render this value on the client UI. */
  minimumOfferIdr: number;
  /** Hidden from buyers. Never render this value on the client UI. */
  minimumOfferUsd: number;
  size: string;
  color: string;
  condition: ConditionScore;
  conditionNotes: string[];
  authenticity: AuthenticityStatus;
  measurements: Measurements;
  images: ProductImage[];
  shippingFrom: string;
  shopeeUrl?: string;
  grailedUrl?: string;
  inventoryStatus: InventoryStatus;
  publishedAt: string; // ISO date
}

export interface ShippingRegion {
  id: string;
  name: string;
  enabled: boolean;
  feeIdr: number;
  feeUsd: number;
  minDays: number;
  maxDays: number;
}

export type OrderStatus =
  | "Order Confirmed"
  | "Waiting for Seller"
  | "Product Being Reviewed"
  | "Quality Check Completed"
  | "Preparing Shipment"
  | "Shipped"
  | "Delivered"
  | "Completed"
  | "Inspection Issue";

export interface OrderTimelineEvent {
  status: OrderStatus;
  timestamp: string; // ISO date
  note?: string;
}

export interface OrderItem {
  productId: string;
  name: string;
  slug: string;
  image: string;
  priceIdr: number;
  priceUsd: number;
  size: string;
  quantity: 1;
}

export interface Order {
  id: string;
  items: OrderItem[];
  status: OrderStatus;
  timeline: OrderTimelineEvent[];
  shippingRegionId: string;
  shippingFeeIdr: number;
  shippingFeeUsd: number;
  totalIdr: number;
  totalUsd: number;
  createdAt: string;
  deliveredAt?: string;
  inspectionNotes?: string;
  review?: {
    rating: 1 | 2 | 3 | 4 | 5;
    comment: string;
  };
  returnRequest?: {
    reason: string;
    submittedAt: string;
  };
}

export type OfferStatus =
  | "Pending Review"
  | "Accepted"
  | "Rejected"
  | "Countered"
  | "Expired"
  | "Auto-Rejected";

export interface Offer {
  id: string;
  productId: string;
  offerIdr: number;
  offerUsd: number;
  status: OfferStatus;
  createdAt: string;
  expiresAt: string;
  counterIdr?: number;
  counterUsd?: number;
}

export type Currency = "IDR" | "USD";
export type Locale = "en" | "id";
