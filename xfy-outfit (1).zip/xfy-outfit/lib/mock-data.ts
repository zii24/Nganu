import type { Product } from "./types";

// ---------------------------------------------------------------------------
// Helpers — dates are generated relative to "now" so the New Drop window
// (72h) demonstrates correctly no matter when this project is run.
// Replace this whole module with API calls once a backend exists.
// ---------------------------------------------------------------------------

function hoursAgo(h: number) {
  return new Date(Date.now() - h * 60 * 60 * 1000).toISOString();
}

function daysAgo(d: number) {
  return hoursAgo(d * 24);
}

function img(seed: string, kind: Product["images"][number]["kind"], alt: string): Product["images"][number] {
  return {
    url: `https://picsum.photos/seed/${seed}/1000/1250`,
    kind,
    alt,
  };
}

function gallery(seed: string, name: string, includeDefect = false): Product["images"] {
  const base: Product["images"] = [
    img(`${seed}-front`, "front", `${name} — front`),
    img(`${seed}-back`, "back", `${name} — back`),
    img(`${seed}-tag`, "tag", `${name} — brand tag`),
    img(`${seed}-wash`, "wash_tag", `${name} — wash / care tag`),
    img(`${seed}-detail`, "detail", `${name} — fabric detail`),
  ];
  if (includeDefect) {
    base.push(img(`${seed}-defect`, "defect", `${name} — condition note close-up`));
  }
  return base;
}

export const PRODUCTS: Product[] = [
  {
    id: "p01",
    slug: "champion-reverse-weave-hoodie-grey",
    name: "Reverse Weave Hoodie",
    brand: "Champion",
    category: "Hoodies",
    descriptionEn:
      "A heavyweight Reverse Weave hoodie in heather grey, the original anti-shrink construction Champion built for collegiate athletics in the 1930s. Brushed fleece interior, ribbed cuffs and hem holding their shape well.",
    descriptionId:
      "Hoodie Reverse Weave heavyweight warna abu-abu heather, konstruksi anti-menyusut asli yang dibuat Champion untuk atletik kampus sejak era 1930-an. Bagian dalam fleece disikat, manset dan bagian bawah rib masih rapi.",
    priceIdr: 450000,
    priceUsd: 29,
    minimumOfferIdr: 380000,
    minimumOfferUsd: 25,
    size: "L",
    color: "Heather Grey",
    condition: 9,
    conditionNotes: ["Minor thread pull near left cuff, barely visible when worn", "Print remains crisp with no cracking"],
    authenticity: "Original",
    measurements: { length: 71, chestWidth: 61, shoulder: 56, sleeve: 61 },
    images: gallery("champion-hoodie", "Champion Reverse Weave Hoodie"),
    shippingFrom: "Jakarta, Indonesia",
    shopeeUrl: "https://shopee.co.id/xfyoutfit",
    grailedUrl: "https://grailed.com/listings/xfy-champion-hoodie",
    inventoryStatus: "Published",
    publishedAt: hoursAgo(20),
  },
  {
    id: "p02",
    slug: "carhartt-wip-detroit-jacket-brown",
    name: "Detroit Jacket",
    brand: "Carhartt WIP",
    category: "Jackets",
    descriptionEn:
      "Duck canvas Detroit Jacket in a rich brown colorway, blanket-lined for warmth. A workwear staple that only improves with age — the canvas here has softened into a broken-in hand feel without losing structure.",
    descriptionId:
      "Detroit Jacket bahan duck canvas warna coklat, dilapisi blanket lining untuk kehangatan. Item workwear klasik yang semakin bagus seiring waktu — canvas sudah terasa lebih lembut namun strukturnya tetap terjaga.",
    priceIdr: 1250000,
    priceUsd: 80,
    minimumOfferIdr: 1050000,
    minimumOfferUsd: 68,
    size: "M",
    color: "Brown",
    condition: 8,
    conditionNotes: ["Light fading on both elbows from wear", "Small mark on right chest pocket, not visible at a glance", "Blanket lining fully intact"],
    authenticity: "Original",
    measurements: { length: 68, chestWidth: 58, shoulder: 50, sleeve: 63 },
    images: gallery("carhartt-jacket", "Carhartt WIP Detroit Jacket", true),
    shippingFrom: "Bandung, Indonesia",
    grailedUrl: "https://grailed.com/listings/xfy-carhartt-detroit",
    inventoryStatus: "Published",
    publishedAt: daysAgo(15),
  },
  {
    id: "p03",
    slug: "patagonia-better-sweater-fleece-navy",
    name: "Better Sweater Fleece",
    brand: "Patagonia",
    category: "Knitwear",
    descriptionEn:
      "The Better Sweater in classic navy — a sweater-knit fleece face with a smooth jersey lining, standing collar, and full-zip front. Genuinely styles like knitwear while performing like fleece.",
    descriptionId:
      "Better Sweater warna navy klasik — fleece dengan tampilan rajut, lapisan dalam jersey halus, kerah berdiri, dan ritsleting penuh di depan. Gaya seperti knitwear namun performa seperti fleece.",
    priceIdr: 950000,
    priceUsd: 61,
    minimumOfferIdr: 800000,
    minimumOfferUsd: 52,
    size: "M",
    color: "Navy",
    condition: 9,
    conditionNotes: ["Zipper pull replaced with matching OEM part, functions perfectly", "No pilling on the knit face"],
    authenticity: "Original",
    measurements: { length: 66, chestWidth: 56, shoulder: 49, sleeve: 60 },
    images: gallery("patagonia-fleece", "Patagonia Better Sweater Fleece"),
    shippingFrom: "Jakarta, Indonesia",
    shopeeUrl: "https://shopee.co.id/xfyoutfit",
    inventoryStatus: "Published",
    publishedAt: hoursAgo(50),
  },
  {
    id: "p04",
    slug: "uniqlo-u-oversized-tee-off-white",
    name: "U Oversized Crew Tee",
    brand: "Uniqlo U",
    category: "T-Shirts",
    descriptionEn:
      "Heavyweight cotton tee from the Uniqlo U line in off white, cut with a relaxed, dropped-shoulder silhouette. Barely worn — closer to deadstock than most second-hand basics.",
    descriptionId:
      "Kaos cotton heavyweight dari lini Uniqlo U warna off white, potongan relaxed dengan bahu turun. Pemakaian sangat minim — kondisinya mendekati deadstock dibanding basic second lain pada umumnya.",
    priceIdr: 180000,
    priceUsd: 12,
    minimumOfferIdr: 150000,
    minimumOfferUsd: 10,
    size: "L",
    color: "Off White",
    condition: 10,
    conditionNotes: ["No flaws found on inspection", "Fabric hand feels unwashed"],
    authenticity: "Original",
    measurements: { length: 72, chestWidth: 60, shoulder: 58, sleeve: 24 },
    images: gallery("uniqlo-tee", "Uniqlo U Oversized Tee"),
    shippingFrom: "Yogyakarta, Indonesia",
    inventoryStatus: "Published",
    publishedAt: daysAgo(30),
  },
  {
    id: "p05",
    slug: "levis-501-original-jeans-indigo",
    name: "501 Original Jeans",
    brand: "Levi's",
    category: "Jeans",
    descriptionEn:
      "The 501, in a mid-wash indigo that's earned its fade honestly. Straight leg, button fly, and enough life left in the denim for years more wear.",
    descriptionId:
      "501 Original dengan warna indigo mid-wash yang fade-nya terbentuk alami. Potongan straight leg, kancing depan, dan denim yang masih tahan lama untuk dipakai bertahun-tahun ke depan.",
    priceIdr: 420000,
    priceUsd: 27,
    minimumOfferIdr: 350000,
    minimumOfferUsd: 23,
    size: "32x32",
    color: "Indigo",
    condition: 7,
    conditionNotes: ["Natural whiskering and fading from wear, consistent with age", "Small frayed spot at right back pocket corner (see photo)", "Hem shows light wear, no holes"],
    authenticity: "Original",
    measurements: { waist: 41, rise: 28, inseam: 81, legOpening: 18 },
    images: gallery("levis-jeans", "Levi's 501 Original Jeans", true),
    shippingFrom: "Jakarta, Indonesia",
    shopeeUrl: "https://shopee.co.id/xfyoutfit",
    grailedUrl: "https://grailed.com/listings/xfy-levis-501",
    inventoryStatus: "Published",
    publishedAt: daysAgo(60),
  },
  {
    id: "p06",
    slug: "stussy-basic-long-sleeve-black",
    name: "Basic Long Sleeve Tee",
    brand: "Stüssy",
    category: "Long Sleeve",
    descriptionEn:
      "A wardrobe-staple long sleeve in black with the small embroidered logo at the chest. Mid-weight jersey that layers cleanly under jackets or works on its own.",
    descriptionId:
      "Long sleeve dasar warna hitam dengan logo bordir kecil di dada. Jersey mid-weight yang enak dipakai layering di bawah jaket maupun sendiri.",
    priceIdr: 320000,
    priceUsd: 21,
    minimumOfferIdr: 270000,
    minimumOfferUsd: 17,
    size: "M",
    color: "Black",
    condition: 8,
    conditionNotes: ["Slight fading from repeated wash, more visible in direct light", "Logo embroidery fully intact"],
    authenticity: "Original",
    measurements: { length: 70, chestWidth: 53, shoulder: 48, sleeve: 62 },
    images: gallery("stussy-longsleeve", "Stüssy Basic Long Sleeve"),
    shippingFrom: "Bandung, Indonesia",
    inventoryStatus: "Reserved",
    publishedAt: daysAgo(5),
  },
  {
    id: "p07",
    slug: "dickies-874-work-pants-olive",
    name: "874 Original Fit Work Pant",
    brand: "Dickies",
    category: "Pants",
    descriptionEn:
      "The 874, in olive twill. Straight through the leg with a flat front — the do-everything pant that started in workwear and never really left streetwear either.",
    descriptionId:
      "874 dengan bahan twill warna olive. Potongan straight dan flat front — celana serbaguna yang berasal dari workwear namun juga tetap relevan di streetwear.",
    priceIdr: 280000,
    priceUsd: 18,
    minimumOfferIdr: 230000,
    minimumOfferUsd: 15,
    size: "32",
    color: "Olive",
    condition: 8,
    conditionNotes: ["Light creasing behind the knees from wear", "Original hem, unaltered"],
    authenticity: "Original",
    measurements: { waist: 42, rise: 30, inseam: 79, legOpening: 20 },
    images: gallery("dickies-pants", "Dickies 874 Work Pant"),
    shippingFrom: "Surabaya, Indonesia",
    shopeeUrl: "https://shopee.co.id/xfyoutfit",
    inventoryStatus: "Published",
    publishedAt: daysAgo(10),
  },
  {
    id: "p08",
    slug: "ralph-lauren-oxford-shirt-light-blue",
    name: "Oxford Button-Down Shirt",
    brand: "Polo Ralph Lauren",
    category: "Shirts",
    descriptionEn:
      "A classic light blue Oxford with the embroidered pony at the chest. Button-down collar, single chest pocket — the archetypal preppy staple in genuinely excellent shape.",
    descriptionId:
      "Oxford shirt biru muda klasik dengan bordir pony di dada. Kerah button-down, satu saku dada — item preppy klasik dengan kondisi yang sangat terjaga.",
    priceIdr: 380000,
    priceUsd: 25,
    minimumOfferIdr: 320000,
    minimumOfferUsd: 21,
    size: "M",
    color: "Light Blue",
    condition: 9,
    conditionNotes: ["Faint pen mark inside left cuff, not visible when worn", "Collar retains its shape well"],
    authenticity: "Original",
    measurements: { length: 76, chestWidth: 57, shoulder: 47, sleeve: 63 },
    images: gallery("rl-oxford", "Polo Ralph Lauren Oxford Shirt"),
    shippingFrom: "Jakarta, Indonesia",
    grailedUrl: "https://grailed.com/listings/xfy-rl-oxford",
    inventoryStatus: "Published",
    publishedAt: hoursAgo(10),
  },
  {
    id: "p09",
    slug: "nike-woven-shorts-black",
    name: "Woven Training Shorts",
    brand: "Nike",
    category: "Shorts",
    descriptionEn:
      "Lightweight woven shorts in black with an elasticated drawstring waist and side pockets. Barely-there wear, ready for both training and everyday rotation.",
    descriptionId:
      "Celana pendek woven ringan warna hitam dengan pinggang elastis dan tali serut serta saku samping. Pemakaian sangat minim, siap untuk olahraga maupun harian.",
    priceIdr: 220000,
    priceUsd: 14,
    minimumOfferIdr: 180000,
    minimumOfferUsd: 12,
    size: "L",
    color: "Black",
    condition: 9,
    conditionNotes: ["Drawstring shows minor fraying at the aglet", "No fading on the swoosh print"],
    authenticity: "Original",
    measurements: { length: 46, waist: 40, inseam: 18 },
    images: gallery("nike-shorts", "Nike Woven Training Shorts"),
    shippingFrom: "Jakarta, Indonesia",
    inventoryStatus: "Published",
    publishedAt: daysAgo(40),
  },
  {
    id: "p10",
    slug: "acne-studios-wool-beanie-charcoal",
    name: "Ribbed Wool Beanie",
    brand: "Acne Studios",
    category: "Accessories",
    descriptionEn:
      "A ribbed wool beanie in charcoal with the woven face-logo patch. Compact fold, dense knit — the kind of quiet accessory that upgrades everything else in the fit.",
    descriptionId:
      "Beanie wol rib warna charcoal dengan patch logo wajah. Lipatan rapat, rajutan padat — aksesori simpel yang mengangkat keseluruhan tampilan.",
    priceIdr: 650000,
    priceUsd: 42,
    minimumOfferIdr: 550000,
    minimumOfferUsd: 36,
    size: "One Size",
    color: "Charcoal",
    condition: 9,
    conditionNotes: ["Patch shows very light surface wear", "Ribbing holds shape, no stretching"],
    authenticity: "Original",
    measurements: {},
    images: gallery("acne-beanie", "Acne Studios Wool Beanie"),
    shippingFrom: "Jakarta, Indonesia",
    inventoryStatus: "Sold",
    publishedAt: daysAgo(20),
  },
  {
    id: "p11",
    slug: "champion-crewneck-sweatshirt-heather-grey",
    name: "Powerblend Crewneck Sweatshirt",
    brand: "Champion",
    category: "Sweatshirts",
    descriptionEn:
      "A mid-weight Powerblend crewneck in heather grey with the classic embroidered C logo at the chest. Everyday layering piece with plenty of life left.",
    descriptionId:
      "Crewneck Powerblend mid-weight warna abu-abu heather dengan logo bordir C klasik di dada. Item layering harian dengan sisa umur pakai yang masih panjang.",
    priceIdr: 350000,
    priceUsd: 23,
    minimumOfferIdr: 290000,
    minimumOfferUsd: 19,
    size: "L",
    color: "Heather Grey",
    condition: 8,
    conditionNotes: ["Light pilling under both arms", "Ribbed cuffs slightly stretched but retain recovery"],
    authenticity: "Original",
    measurements: { length: 68, chestWidth: 60, shoulder: 55, sleeve: 60 },
    images: gallery("champion-crewneck", "Champion Powerblend Crewneck"),
    shippingFrom: "Bandung, Indonesia",
    shopeeUrl: "https://shopee.co.id/xfyoutfit",
    inventoryStatus: "Published",
    publishedAt: daysAgo(8),
  },
  {
    id: "p12",
    slug: "cdg-play-cardigan-black",
    name: "PLAY Wool Cardigan",
    brand: "Comme des Garçons PLAY",
    category: "Knitwear",
    descriptionEn:
      "A black wool cardigan from PLAY with the heart logo at the chest. Currently being catalogued by the XFY inspection team — not yet listed for sale.",
    descriptionId:
      "Cardigan wol hitam dari lini PLAY dengan logo hati di dada. Saat ini masih dalam proses katalogisasi oleh tim inspeksi XFY — belum dipublikasikan untuk dijual.",
    priceIdr: 1450000,
    priceUsd: 94,
    minimumOfferIdr: 1250000,
    minimumOfferUsd: 81,
    size: "S",
    color: "Black",
    condition: 9,
    conditionNotes: ["Pending final inspection photos"],
    authenticity: "Original",
    measurements: { length: 64, chestWidth: 50, shoulder: 44, sleeve: 58 },
    images: gallery("cdg-cardigan", "Comme des Garçons PLAY Cardigan"),
    shippingFrom: "Jakarta, Indonesia",
    inventoryStatus: "Draft",
    publishedAt: daysAgo(2),
  },
];

export function getPublishedProducts() {
  // "Published" is purchasable; Reserved/Sold remain visible in the shop
  // (per spec) but cannot be bought. Draft/Archived never surface publicly.
  return PRODUCTS.filter((p) => p.inventoryStatus !== "Draft" && p.inventoryStatus !== "Archived");
}

export function getProductBySlug(slug: string) {
  return PRODUCTS.find((p) => p.slug === slug);
}

export function getActiveCategories() {
  const cats = new Set(getPublishedProducts().map((p) => p.category));
  return Array.from(cats);
}

export function getRelatedProducts(product: Product, limit = 4) {
  return getPublishedProducts()
    .filter((p) => p.id !== product.id && p.category === product.category)
    .concat(getPublishedProducts().filter((p) => p.id !== product.id && p.category !== product.category))
    .slice(0, limit);
}
