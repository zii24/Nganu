"use client";

import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { getEnabledRegions } from "@/lib/mock-shipping";

export interface ShippingAddress {
  fullName: string;
  phone: string;
  regionId: string;
  address: string;
  city: string;
  province: string;
  postalCode: string;
  saveAddress: boolean;
}

export function ShippingForm({
  value,
  onChange,
}: {
  value: ShippingAddress;
  onChange: (next: ShippingAddress) => void;
}) {
  const regions = getEnabledRegions();

  function set<K extends keyof ShippingAddress>(key: K, val: ShippingAddress[K]) {
    onChange({ ...value, [key]: val });
  }

  return (
    <div className="space-y-5">
      <div>
        <Label htmlFor="fullName">Full Name</Label>
        <Input id="fullName" required className="mt-1.5" value={value.fullName} onChange={(e) => set("fullName", e.target.value)} placeholder="John Doe" />
      </div>

      <div>
        <Label htmlFor="phone">Phone Number</Label>
        <Input id="phone" required type="tel" className="mt-1.5" value={value.phone} onChange={(e) => set("phone", e.target.value)} placeholder="+62 812 3456 7890" />
      </div>

      <div>
        <Label htmlFor="region">Destination Country</Label>
        <div className="mt-1.5">
          <Select id="region" value={value.regionId} onChange={(e) => set("regionId", e.target.value)}>
            {regions.map((r) => (
              <option key={r.id} value={r.id}>
                {r.name}
              </option>
            ))}
          </Select>
        </div>
      </div>

      <div>
        <Label htmlFor="address">Address</Label>
        <Input id="address" required className="mt-1.5" value={value.address} onChange={(e) => set("address", e.target.value)} placeholder="Street, building, unit number" />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="city">City</Label>
          <Input id="city" required className="mt-1.5" value={value.city} onChange={(e) => set("city", e.target.value)} />
        </div>
        <div>
          <Label htmlFor="province">Province / State</Label>
          <Input id="province" required className="mt-1.5" value={value.province} onChange={(e) => set("province", e.target.value)} />
        </div>
      </div>

      <div className="w-1/2 pr-2">
        <Label htmlFor="postal">Postal Code</Label>
        <Input id="postal" required className="mt-1.5" value={value.postalCode} onChange={(e) => set("postalCode", e.target.value)} />
      </div>

      <label className="flex items-center gap-2.5 text-sm">
        <Checkbox checked={value.saveAddress} onChange={(e) => set("saveAddress", e.target.checked)} />
        Save this address for next time
      </label>
    </div>
  );
}
