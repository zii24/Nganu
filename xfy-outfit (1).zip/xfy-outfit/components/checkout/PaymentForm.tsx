"use client";

import { Landmark, CreditCard, Wallet } from "lucide-react";
import { cn } from "@/lib/utils";

export type PaymentMethod = "bank_transfer" | "virtual_account" | "card";

const METHODS: { id: PaymentMethod; label: string; sub: string; icon: typeof Landmark }[] = [
  { id: "virtual_account", label: "Virtual Account", sub: "BCA, Mandiri, BNI, BRI", icon: Landmark },
  { id: "card", label: "Credit / Debit Card", sub: "Visa, Mastercard", icon: CreditCard },
  { id: "bank_transfer", label: "Manual Bank Transfer", sub: "Confirm after transfer", icon: Wallet },
];

export function PaymentForm({ value, onChange }: { value: PaymentMethod; onChange: (v: PaymentMethod) => void }) {
  return (
    <div>
      <div className="space-y-2.5">
        {METHODS.map((method) => (
          <label
            key={method.id}
            className={cn(
              "flex cursor-pointer items-center gap-3 border p-4",
              value === method.id ? "border-foreground" : "border-border hover:border-foreground/40"
            )}
          >
            <input
              type="radio"
              name="payment-method"
              className="sr-only"
              checked={value === method.id}
              onChange={() => onChange(method.id)}
            />
            <method.icon className="h-5 w-5 shrink-0 text-muted-foreground" strokeWidth={1.5} />
            <div className="flex-1">
              <p className="text-sm font-medium">{method.label}</p>
              <p className="text-xs text-muted-foreground">{method.sub}</p>
            </div>
            <span
              className={cn(
                "flex h-4 w-4 shrink-0 items-center justify-center rounded-full border",
                value === method.id ? "border-primary" : "border-foreground/30"
              )}
            >
              {value === method.id && <span className="h-2 w-2 rounded-full bg-primary" />}
            </span>
          </label>
        ))}
      </div>
      <p className="mt-4 border border-dashed border-border px-4 py-3 text-xs leading-relaxed text-muted-foreground">
        This is a demo checkout — no real payment is processed. Production payments will route through Xendit
        once connected on the backend.
      </p>
    </div>
  );
}
