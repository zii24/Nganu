import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

const STEPS = ["Shipping", "Payment", "Confirmation"];

export function CheckoutSteps({ current }: { current: number }) {
  return (
    <div className="mb-8 flex items-center">
      {STEPS.map((step, i) => (
        <div key={step} className="flex flex-1 items-center last:flex-none">
          <div className="flex items-center gap-2.5">
            <span
              className={cn(
                "flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-medium",
                i < current ? "bg-primary text-primary-foreground" : i === current ? "border-2 border-primary text-primary" : "border border-border text-muted-foreground"
              )}
            >
              {i < current ? <Check className="h-3.5 w-3.5" /> : i + 1}
            </span>
            <span className={cn("text-sm font-medium", i === current ? "text-foreground" : "text-muted-foreground")}>{step}</span>
          </div>
          {i < STEPS.length - 1 && <span className={cn("mx-4 h-px flex-1", i < current ? "bg-primary" : "bg-border")} />}
        </div>
      ))}
    </div>
  );
}
