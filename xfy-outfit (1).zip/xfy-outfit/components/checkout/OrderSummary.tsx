"use client";

import Image from "next/image";
import type { Product } from "@/lib/types";
import { formatAmount } from "@/lib/utils";
import { useCurrency } from "@/context/CurrencyContext";
import { getRegionById } from "@/lib/mock-shipping";

export function OrderSummary({ items, regionId }: { items: Product[]; regionId: string }) {
  const { currency } = useCurrency();
  const region = getRegionById(regionId);

  const subtotal = items.reduce((sum, p) => sum + (currency === "IDR" ? p.priceIdr : p.priceUsd), 0);
  const shipping = region ? (currency === "IDR" ? region.feeIdr : region.feeUsd) : 0;
  const total = subtotal + shipping;

  return (
    <div className="h-fit border border-border p-6">
      <p className="mb-4 text-sm font-medium">Order Summary</p>
      <div className="space-y-4">
        {items.map((product) => {
          const front = product.images.find((i) => i.kind === "front") ?? product.images[0];
          return (
            <div key={product.id} className="flex gap-3">
              <div className="relative h-16 w-13 shrink-0 overflow-hidden bg-secondary" style={{ width: 52 }}>
                <Image src={front.url} alt={front.alt} fill sizes="52px" className="object-cover" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">{product.name}</p>
                <p className="text-xs text-muted-foreground">
                  {product.brand} · Size {product.size} · Qty 1
                </p>
              </div>
              <p className="shrink-0 text-sm">{formatAmount(currency === "IDR" ? product.priceIdr : product.priceUsd, currency)}</p>
            </div>
          );
        })}
      </div>

      <div className="mt-5 space-y-2.5 border-t border-border pt-4 text-sm">
        <div className="flex justify-between">
          <span className="text-muted-foreground">Subtotal</span>
          <span>{formatAmount(subtotal, currency)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-muted-foreground">Shipping{region ? ` — ${region.name}` : ""}</span>
          <span>{formatAmount(shipping, currency)}</span>
        </div>
      </div>
      <div className="mt-4 flex justify-between border-t border-border pt-4 text-sm font-medium">
        <span>Total</span>
        <span>{formatAmount(total, currency)}</span>
      </div>
    </div>
  );
}
