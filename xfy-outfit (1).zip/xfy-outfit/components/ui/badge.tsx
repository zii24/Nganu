import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center gap-1 border px-2 py-0.5 text-[11px] font-medium tracking-wide rounded-sm",
  {
    variants: {
      variant: {
        default: "bg-foreground text-background border-foreground",
        outline: "bg-transparent text-foreground border-foreground/25",
        primary: "bg-primary text-primary-foreground border-primary",
        muted: "bg-secondary text-secondary-foreground border-transparent",
        success: "bg-success/10 text-success border-success/30",
        destructive: "bg-destructive/10 text-destructive border-destructive/30",
        warning: "bg-amber-50 text-amber-800 border-amber-300",
      },
    },
    defaultVariants: { variant: "default" },
  }
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, ...props }: BadgeProps) {
  return <span className={cn(badgeVariants({ variant, className }))} {...props} />;
}

export { Badge, badgeVariants };
