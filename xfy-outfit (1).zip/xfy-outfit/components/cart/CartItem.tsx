"use client";

import Link from "next/link";
import Image from "next/image";
import { X } from "lucide-react";
import type { Product } from "@/lib/types";
import { CONDITION_LABEL } from "@/lib/types";
import { Price } from "@/components/shared/Price";
import { useCart } from "@/context/CartContext";

export function CartItem({ product }: { product: Product }) {
  const { remove } = useCart();
  const front = product.images.find((i) => i.kind === "front") ?? product.images[0];

  return (
    <div className="flex gap-4 border-b border-border py-5 first:pt-0">
      <Link href={`/product/${product.slug}`} className="relative h-28 w-22 shrink-0 overflow-hidden bg-secondary sm:h-32 sm:w-[104px]">
        <Image src={front.url} alt={front.alt} fill sizes="120px" className="object-cover" />
      </Link>
      <div className="flex flex-1 flex-col justify-between">
        <div>
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-xs text-muted-foreground">{product.brand}</p>
              <Link href={`/product/${product.slug}`} className="text-sm font-medium hover:underline">
                {product.name}
              </Link>
            </div>
            <button
              onClick={() => remove(product.id)}
              aria-label="Remove from cart"
              className="text-muted-foreground hover:text-foreground"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
          <p className="mt-1 text-xs text-muted-foreground">
            Size {product.size} · {CONDITION_LABEL[product.condition]} · Qty 1
          </p>
        </div>
        <Price idr={product.priceIdr} usd={product.priceUsd} className="text-sm font-medium" />
      </div>
    </div>
  );
}
