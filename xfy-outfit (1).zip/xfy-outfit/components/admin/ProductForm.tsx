"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Plus, Trash2, CheckCircle2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import type {
  AuthenticityStatus,
  Category,
  ConditionScore,
  ImageKind,
  InventoryStatus,
  Measurements,
  Product,
} from "@/lib/types";
import { addDraftProduct } from "@/lib/admin-draft-store";
import { slugify } from "@/lib/utils";

const CATEGORIES: Category[] = [
  "T-Shirts",
  "Long Sleeve",
  "Shirts",
  "Hoodies",
  "Sweatshirts",
  "Jackets",
  "Knitwear",
  "Pants",
  "Jeans",
  "Shorts",
  "Accessories",
];

const CONDITIONS: ConditionScore[] = [10, 9, 8, 7, 6];
const AUTHENTICITY_OPTIONS: AuthenticityStatus[] = ["Original", "Not Verified", "Not Original"];
const INVENTORY_OPTIONS: InventoryStatus[] = ["Draft", "Published", "Checkout in Progress", "Reserved", "Sold", "Archived"];
const IMAGE_KINDS: ImageKind[] = ["front", "back", "tag", "wash_tag", "detail", "defect"];
const MEASUREMENT_KEYS: (keyof Measurements)[] = [
  "length",
  "width",
  "chestWidth",
  "shoulder",
  "sleeve",
  "waist",
  "rise",
  "inseam",
  "legOpening",
];
const MEASUREMENT_LABELS: Record<keyof Measurements, string> = {
  length: "Length",
  width: "Width",
  chestWidth: "Chest Width",
  shoulder: "Shoulder",
  sleeve: "Sleeve",
  waist: "Waist",
  rise: "Rise",
  inseam: "Inseam",
  legOpening: "Leg Opening",
};

function Field({ label, htmlFor, children }: { label: string; htmlFor?: string; children: React.ReactNode }) {
  return (
    <div>
      <Label htmlFor={htmlFor}>{label}</Label>
      <div className="mt-1.5">{children}</div>
    </div>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return <h2 className="mb-4 text-sm font-semibold uppercase tracking-wide text-muted-foreground">{children}</h2>;
}

export function ProductForm() {
  const router = useRouter();
  const [saved, setSaved] = useState(false);

  const [name, setName] = useState("");
  const [brand, setBrand] = useState("");
  const [category, setCategory] = useState<Category>(CATEGORIES[0]);
  const [descriptionEn, setDescriptionEn] = useState("");
  const [descriptionId, setDescriptionId] = useState("");
  const [priceIdr, setPriceIdr] = useState("");
  const [priceUsd, setPriceUsd] = useState("");
  const [minOfferIdr, setMinOfferIdr] = useState("");
  const [minOfferUsd, setMinOfferUsd] = useState("");
  const [size, setSize] = useState("");
  const [color, setColor] = useState("");
  const [condition, setCondition] = useState<ConditionScore>(9);
  const [conditionNotes, setConditionNotes] = useState<string[]>([""]);
  const [authenticity, setAuthenticity] = useState<AuthenticityStatus>("Original");
  const [measurements, setMeasurements] = useState<Record<keyof Measurements, string>>({
    length: "",
    width: "",
    chestWidth: "",
    shoulder: "",
    sleeve: "",
    waist: "",
    rise: "",
    inseam: "",
    legOpening: "",
  });
  const [images, setImages] = useState<{ url: string; kind: ImageKind }[]>([{ url: "", kind: "front" }]);
  const [publishedAt, setPublishedAt] = useState(() => new Date().toISOString().slice(0, 10));
  const [shippingFrom, setShippingFrom] = useState("Jakarta, Indonesia");
  const [shopeeUrl, setShopeeUrl] = useState("");
  const [grailedUrl, setGrailedUrl] = useState("");
  const [inventoryStatus, setInventoryStatus] = useState<InventoryStatus>("Draft");

  function updateNote(i: number, value: string) {
    setConditionNotes((prev) => prev.map((n, idx) => (idx === i ? value : n)));
  }
  function updateImage(i: number, patch: Partial<{ url: string; kind: ImageKind }>) {
    setImages((prev) => prev.map((img, idx) => (idx === i ? { ...img, ...patch } : img)));
  }

  const canSubmit = name.trim() && brand.trim() && priceIdr && priceUsd && size.trim() && color.trim();

  function handleSubmit() {
    if (!canSubmit) return;

    const cleanMeasurements: Measurements = {};
    MEASUREMENT_KEYS.forEach((key) => {
      const v = measurements[key];
      if (v.trim()) cleanMeasurements[key] = Number(v);
    });

    const product: Product = {
      id: `draft-${Date.now()}`,
      slug: `${slugify(name)}-${Date.now().toString().slice(-5)}`,
      name,
      brand,
      category,
      descriptionEn,
      descriptionId: descriptionId || descriptionEn,
      priceIdr: Number(priceIdr),
      priceUsd: Number(priceUsd),
      minimumOfferIdr: Number(minOfferIdr) || Math.round(Number(priceIdr) * 0.85),
      minimumOfferUsd: Number(minOfferUsd) || Math.round(Number(priceUsd) * 0.85),
      size,
      color,
      condition,
      conditionNotes: conditionNotes.filter((n) => n.trim()),
      authenticity,
      measurements: cleanMeasurements,
      images: images.filter((img) => img.url.trim()).map((img) => ({ url: img.url, kind: img.kind, alt: `${name} — ${img.kind}` })),
      shippingFrom,
      shopeeUrl: shopeeUrl.trim() || undefined,
      grailedUrl: grailedUrl.trim() || undefined,
      inventoryStatus,
      publishedAt: new Date(publishedAt).toISOString(),
    };

    addDraftProduct(product);
    setSaved(true);
    setTimeout(() => router.push("/admin/products"), 1200);
  }

  if (saved) {
    return (
      <div className="flex flex-col items-center border border-success/30 bg-success/5 px-6 py-16 text-center">
        <CheckCircle2 className="h-8 w-8 text-success" strokeWidth={1.5} />
        <p className="mt-3 text-sm font-medium text-success">Product saved</p>
        <p className="mt-1 text-sm text-muted-foreground">Redirecting to Products…</p>
      </div>
    );
  }

  return (
    <div className="max-w-3xl space-y-10">
      <section>
        <SectionTitle>Basic Info</SectionTitle>
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
          <Field label="Name" htmlFor="name">
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Reverse Weave Hoodie" />
          </Field>
          <Field label="Brand" htmlFor="brand">
            <Input id="brand" value={brand} onChange={(e) => setBrand(e.target.value)} placeholder="Champion" />
          </Field>
          <Field label="Category" htmlFor="category">
            <Select id="category" value={category} onChange={(e) => setCategory(e.target.value as Category)}>
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Inventory Status" htmlFor="status">
            <Select id="status" value={inventoryStatus} onChange={(e) => setInventoryStatus(e.target.value as InventoryStatus)}>
              {INVENTORY_OPTIONS.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </Select>
          </Field>
        </div>

        <div className="mt-5 grid grid-cols-1 gap-5 sm:grid-cols-2">
          <Field label="Description (EN)" htmlFor="descEn">
            <Textarea id="descEn" value={descriptionEn} onChange={(e) => setDescriptionEn(e.target.value)} rows={4} />
          </Field>
          <Field label="Description (ID)" htmlFor="descId">
            <Textarea id="descId" value={descriptionId} onChange={(e) => setDescriptionId(e.target.value)} rows={4} />
          </Field>
        </div>
      </section>

      <Separator />

      <section>
        <SectionTitle>Pricing</SectionTitle>
        <div className="grid grid-cols-2 gap-5 sm:grid-cols-4">
          <Field label="Price (IDR)" htmlFor="priceIdr">
            <Input id="priceIdr" type="number" value={priceIdr} onChange={(e) => setPriceIdr(e.target.value)} />
          </Field>
          <Field label="Price (USD)" htmlFor="priceUsd">
            <Input id="priceUsd" type="number" value={priceUsd} onChange={(e) => setPriceUsd(e.target.value)} />
          </Field>
          <Field label="Minimum Offer (IDR)" htmlFor="minIdr">
            <Input id="minIdr" type="number" value={minOfferIdr} onChange={(e) => setMinOfferIdr(e.target.value)} placeholder="Optional" />
          </Field>
          <Field label="Minimum Offer (USD)" htmlFor="minUsd">
            <Input id="minUsd" type="number" value={minOfferUsd} onChange={(e) => setMinOfferUsd(e.target.value)} placeholder="Optional" />
          </Field>
        </div>
        <p className="mt-2 text-xs text-muted-foreground">
          Minimum offer is never shown to buyers — it's used only to auto-evaluate Make an Offer submissions.
        </p>
      </section>

      <Separator />

      <section>
        <SectionTitle>Variant</SectionTitle>
        <div className="grid grid-cols-2 gap-5 sm:grid-cols-4">
          <Field label="Size" htmlFor="size">
            <Input id="size" value={size} onChange={(e) => setSize(e.target.value)} placeholder="M, 32x32, One Size" />
          </Field>
          <Field label="Color" htmlFor="color">
            <Input id="color" value={color} onChange={(e) => setColor(e.target.value)} />
          </Field>
          <Field label="Condition" htmlFor="condition">
            <Select id="condition" value={condition} onChange={(e) => setCondition(Number(e.target.value) as ConditionScore)}>
              {CONDITIONS.map((c) => (
                <option key={c} value={c}>
                  {c}/10
                </option>
              ))}
            </Select>
          </Field>
          <Field label="Authenticity" htmlFor="authenticity">
            <Select id="authenticity" value={authenticity} onChange={(e) => setAuthenticity(e.target.value as AuthenticityStatus)}>
              {AUTHENTICITY_OPTIONS.map((a) => (
                <option key={a} value={a}>
                  {a}
                </option>
              ))}
            </Select>
          </Field>
        </div>

        <div className="mt-5">
          <Label>Condition Notes</Label>
          <div className="mt-1.5 space-y-2">
            {conditionNotes.map((note, i) => (
              <div key={i} className="flex gap-2">
                <Input value={note} onChange={(e) => updateNote(i, e.target.value)} placeholder="e.g. Light fading on both elbows" />
                <button
                  type="button"
                  onClick={() => setConditionNotes((prev) => prev.filter((_, idx) => idx !== i))}
                  className="flex h-11 w-11 shrink-0 items-center justify-center border border-border text-muted-foreground hover:text-destructive"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
            <button
              type="button"
              onClick={() => setConditionNotes((prev) => [...prev, ""])}
              className="flex items-center gap-1.5 text-sm text-primary hover:underline"
            >
              <Plus className="h-3.5 w-3.5" /> Add note
            </button>
          </div>
        </div>
      </section>

      <Separator />

      <section>
        <SectionTitle>Measurements (cm, optional)</SectionTitle>
        <div className="grid grid-cols-2 gap-5 sm:grid-cols-3">
          {MEASUREMENT_KEYS.map((key) => (
            <Field key={key} label={MEASUREMENT_LABELS[key]} htmlFor={key}>
              <Input
                id={key}
                type="number"
                value={measurements[key]}
                onChange={(e) => setMeasurements((prev) => ({ ...prev, [key]: e.target.value }))}
              />
            </Field>
          ))}
        </div>
      </section>

      <Separator />

      <section>
        <SectionTitle>Images</SectionTitle>
        <div className="space-y-3">
          {images.map((img, i) => (
            <div key={i} className="flex gap-2">
              <Input
                value={img.url}
                onChange={(e) => updateImage(i, { url: e.target.value })}
                placeholder="https://…"
                className="flex-1"
              />
              <div className="w-40 shrink-0">
                <Select value={img.kind} onChange={(e) => updateImage(i, { kind: e.target.value as ImageKind })}>
                  {IMAGE_KINDS.map((k) => (
                    <option key={k} value={k}>
                      {k.replace("_", " ")}
                    </option>
                  ))}
                </Select>
              </div>
              <button
                type="button"
                onClick={() => setImages((prev) => prev.filter((_, idx) => idx !== i))}
                className="flex h-11 w-11 shrink-0 items-center justify-center border border-border text-muted-foreground hover:text-destructive"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          ))}
          <button
            type="button"
            onClick={() => setImages((prev) => [...prev, { url: "", kind: "detail" }])}
            className="flex items-center gap-1.5 text-sm text-primary hover:underline"
          >
            <Plus className="h-3.5 w-3.5" /> Add image
          </button>
        </div>
      </section>

      <Separator />

      <section>
        <SectionTitle>Logistics &amp; Listing</SectionTitle>
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
          <Field label="Published At" htmlFor="publishedAt">
            <Input id="publishedAt" type="date" value={publishedAt} onChange={(e) => setPublishedAt(e.target.value)} />
          </Field>
          <Field label="Shipping From" htmlFor="shippingFrom">
            <Input id="shippingFrom" value={shippingFrom} onChange={(e) => setShippingFrom(e.target.value)} />
          </Field>
          <Field label="Shopee URL (optional)" htmlFor="shopeeUrl">
            <Input id="shopeeUrl" value={shopeeUrl} onChange={(e) => setShopeeUrl(e.target.value)} placeholder="https://shopee.co.id/…" />
          </Field>
          <Field label="Grailed URL (optional)" htmlFor="grailedUrl">
            <Input id="grailedUrl" value={grailedUrl} onChange={(e) => setGrailedUrl(e.target.value)} placeholder="https://grailed.com/…" />
          </Field>
        </div>
      </section>

      <div className="flex items-center gap-3 border-t border-border pt-6">
        <Button onClick={handleSubmit} disabled={!canSubmit}>
          Save Product
        </Button>
        <p className="text-xs text-muted-foreground">Saved locally in your browser for this prototype — no live backend yet.</p>
      </div>
    </div>
  );
}
