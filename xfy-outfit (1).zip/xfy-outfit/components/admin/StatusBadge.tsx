import { Badge } from "@/components/ui/badge";
import type { InventoryStatus, OrderStatus, OfferStatus } from "@/lib/types";

const VARIANT: Record<string, "default" | "outline" | "primary" | "muted" | "success" | "destructive" | "warning"> = {
  Published: "success",
  Available: "success",
  Draft: "muted",
  Reserved: "warning",
  "Checkout in Progress": "warning",
  Sold: "default",
  Archived: "muted",
  "Order Confirmed": "muted",
  "Waiting for Seller": "warning",
  "Product Being Reviewed": "warning",
  "Quality Check Completed": "primary",
  "Preparing Shipment": "primary",
  Shipped: "primary",
  Delivered: "success",
  Completed: "success",
  "Inspection Issue": "destructive",
  "Pending Review": "warning",
  Accepted: "success",
  Rejected: "destructive",
  Countered: "primary",
  Expired: "muted",
  "Auto-Rejected": "destructive",
};

export function StatusBadge({ status }: { status: InventoryStatus | OrderStatus | OfferStatus }) {
  return <Badge variant={VARIANT[status] ?? "outline"}>{status}</Badge>;
}
