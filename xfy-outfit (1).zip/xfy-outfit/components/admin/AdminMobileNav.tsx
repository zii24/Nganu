"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";

const LINKS = [
  { href: "/admin", label: "Dashboard" },
  { href: "/admin/products", label: "Products" },
  { href: "/admin/orders", label: "Orders" },
  { href: "/admin/shipping", label: "Shipping" },
];

export function AdminMobileNav() {
  const pathname = usePathname();

  return (
    <div className="sticky top-0 z-30 border-b border-border bg-foreground text-background lg:hidden">
      <div className="flex h-14 items-center px-4">
        <span className="text-sm font-semibold">
          XFY <span className="font-normal text-background/60">Admin</span>
        </span>
      </div>
      <nav className="no-scrollbar flex gap-1 overflow-x-auto px-3 pb-2.5">
        {LINKS.map((link) => {
          const active = link.href === "/admin" ? pathname === "/admin" : pathname?.startsWith(link.href);
          return (
            <Link
              key={link.href}
              href={link.href}
              className={cn(
                "shrink-0 px-3 py-1.5 text-xs font-medium rounded-sm",
                active ? "bg-background text-foreground" : "text-background/70"
              )}
            >
              {link.label}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
