"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  Truck,
  LogOut,
  PlusCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";

const LINKS = [
  { href: "/admin", label: "Dashboard", icon: LayoutDashboard },
  { href: "/admin/products", label: "Products", icon: Package },
  { href: "/admin/orders", label: "Orders", icon: ShoppingCart },
  { href: "/admin/shipping", label: "Shipping", icon: Truck },
];

export function AdminSidebar() {
  const pathname = usePathname();

  return (
    <aside className="fixed inset-y-0 left-0 z-30 hidden w-60 flex-col border-r border-white/10 bg-foreground text-background lg:flex">
      <div className="flex h-16 items-center border-b border-white/10 px-6">
        <span className="text-base font-semibold tracking-tight">
          XFY <span className="font-normal text-background/60">Admin</span>
        </span>
      </div>

      <nav className="flex-1 space-y-1 px-3 py-5">
        {LINKS.map((link) => {
          const active = link.href === "/admin" ? pathname === "/admin" : pathname?.startsWith(link.href);
          return (
            <Link
              key={link.href}
              href={link.href}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-sm",
                active ? "bg-background text-foreground" : "text-background/70 hover:bg-white/5 hover:text-background"
              )}
            >
              <link.icon className="h-4 w-4" strokeWidth={1.5} />
              {link.label}
            </Link>
          );
        })}

        <Link
          href="/admin/products/new"
          className="mt-4 flex items-center gap-3 border border-dashed border-background/25 px-3 py-2.5 text-sm font-medium text-background/80 hover:border-background/50 hover:text-background rounded-sm"
        >
          <PlusCircle className="h-4 w-4" strokeWidth={1.5} />
          Add Product
        </Link>
      </nav>

      <div className="border-t border-white/10 p-3">
        <Link
          href="/"
          className="flex items-center gap-3 px-3 py-2.5 text-sm font-medium text-background/70 hover:bg-white/5 hover:text-background rounded-sm"
        >
          <LogOut className="h-4 w-4" strokeWidth={1.5} />
          Log Out
        </Link>
      </div>
    </aside>
  );
}
