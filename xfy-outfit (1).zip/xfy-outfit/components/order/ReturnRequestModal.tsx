"use client";

import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";

const REASONS = [
  "Item significantly differs from description",
  "Condition differs from listing",
  "Wrong item",
  "Measurement issue",
  "Authenticity concern",
  "Damage during delivery",
  "Other",
];

export function ReturnRequestModal({
  open,
  onOpenChange,
  orderId,
  onSubmitted,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  orderId: string;
  onSubmitted: (reason: string) => void;
}) {
  const [reason, setReason] = useState(REASONS[0]);
  const [notes, setNotes] = useState("");

  function handleSubmit() {
    onSubmitted(reason);
    const message = encodeURIComponent(
      `Hi XFY, I'd like to request a return for order ${orderId}.\nReason: ${reason}${notes ? `\nNotes: ${notes}` : ""}`
    );
    window.open(`https://wa.me/6281234567890?text=${message}`, "_blank");
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent onClose={() => onOpenChange(false)} className="max-w-md">
        <DialogHeader>
          <DialogTitle>Request a Return</DialogTitle>
          <p className="mt-1.5 text-sm text-muted-foreground">
            Return requests must be submitted within 7 days after delivery, subject to XFY's Return Policy.
          </p>
        </DialogHeader>

        <Label htmlFor="reason">Reason</Label>
        <div className="mt-1.5">
          <Select id="reason" value={reason} onChange={(e) => setReason(e.target.value)}>
            {REASONS.map((r) => (
              <option key={r} value={r}>
                {r}
              </option>
            ))}
          </Select>
        </div>

        <Label htmlFor="notes" className="mt-4 block">
          Additional details (optional)
        </Label>
        <Textarea id="notes" className="mt-1.5" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Tell us more about the issue" />

        <Button className="mt-5 w-full" onClick={handleSubmit}>
          Continue on WhatsApp
        </Button>
        <p className="mt-2.5 text-center text-xs text-muted-foreground">
          You'll be redirected to XFY Support on WhatsApp to complete your return request.
        </p>
      </DialogContent>
    </Dialog>
  );
}
