"use client";

import { useState } from "react";
import { StarRating } from "@/components/shared/StarRating";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";

export function ReviewForm({ onSubmit }: { onSubmit: (rating: 1 | 2 | 3 | 4 | 5, comment: string) => void }) {
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");
  const [submitted, setSubmitted] = useState(false);

  if (submitted) {
    return (
      <div className="flex items-center gap-2 border border-success/30 bg-success/5 px-4 py-3 text-sm text-success">
        <Check className="h-4 w-4" /> Thanks — your review has been submitted.
      </div>
    );
  }

  return (
    <div className="border border-border p-5">
      <p className="text-sm font-medium">Rate this order</p>
      <div className="mt-3">
        <StarRating value={rating} onChange={setRating} />
      </div>
      <Textarea
        className="mt-4"
        placeholder="How was the condition, fit, and overall experience?"
        value={comment}
        onChange={(e) => setComment(e.target.value)}
      />
      <Button
        className="mt-4"
        disabled={rating === 0}
        onClick={() => {
          onSubmit(rating as 1 | 2 | 3 | 4 | 5, comment);
          setSubmitted(true);
        }}
      >
        Submit Review
      </Button>
    </div>
  );
}
