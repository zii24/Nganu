import { Check, TriangleAlert } from "lucide-react";
import type { OrderStatus, OrderTimelineEvent } from "@/lib/types";
import { formatDateTime, cn } from "@/lib/utils";

const SEQUENCE: OrderStatus[] = [
  "Order Confirmed",
  "Waiting for Seller",
  "Product Being Reviewed",
  "Quality Check Completed",
  "Preparing Shipment",
  "Shipped",
  "Delivered",
  "Completed",
];

export function Timeline({ timeline, currentStatus }: { timeline: OrderTimelineEvent[]; currentStatus: OrderStatus }) {
  const reachedIndex = SEQUENCE.indexOf(currentStatus === "Inspection Issue" ? timeline[timeline.length - 2]?.status ?? "Order Confirmed" : currentStatus);
  const hasIssue = currentStatus === "Inspection Issue" || timeline.some((e) => e.status === "Inspection Issue");
  const issueEvent = timeline.find((e) => e.status === "Inspection Issue");

  function eventFor(status: OrderStatus) {
    return timeline.find((e) => e.status === status);
  }

  return (
    <div>
      <ol>
        {SEQUENCE.map((status, i) => {
          const event = eventFor(status);
          const done = i <= reachedIndex;
          const isLast = i === SEQUENCE.length - 1;
          return (
            <li key={status} className="relative flex gap-4 pb-8 last:pb-0">
              {!isLast && (
                <span
                  className={cn("absolute left-[13px] top-7 h-[calc(100%-12px)] w-px", done && i < reachedIndex ? "bg-foreground" : "bg-border")}
                />
              )}
              <span
                className={cn(
                  "z-10 flex h-7 w-7 shrink-0 items-center justify-center rounded-full border text-xs",
                  done ? "border-foreground bg-foreground text-background" : "border-border text-muted-foreground"
                )}
              >
                {done ? <Check className="h-3.5 w-3.5" /> : i + 1}
              </span>
              <div className="pt-0.5">
                <p className={cn("text-sm font-medium", !done && "text-muted-foreground")}>{status}</p>
                {event && <p className="mt-0.5 text-xs text-muted-foreground">{formatDateTime(event.timestamp)}</p>}
                {event?.note && <p className="mt-1 text-xs text-muted-foreground">{event.note}</p>}
              </div>
            </li>
          );
        })}
      </ol>

      {hasIssue && issueEvent && (
        <div className="mt-2 flex gap-4 border-t border-dashed border-destructive/30 pt-6">
          <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-destructive bg-destructive/10 text-destructive">
            <TriangleAlert className="h-3.5 w-3.5" />
          </span>
          <div>
            <p className="text-sm font-medium text-destructive">Inspection Issue</p>
            <p className="mt-0.5 text-xs text-muted-foreground">{formatDateTime(issueEvent.timestamp)}</p>
            <p className="mt-1 text-xs text-muted-foreground">
              XFY found a discrepancy during inspection. See the note below for details and next steps.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
