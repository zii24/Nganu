"use client";

import Link from "next/link";
import { Sheet } from "@/components/ui/sheet";
import { CurrencyLanguageToggle } from "./CurrencyLanguageToggle";
import { useLanguage } from "@/context/LanguageContext";
import { Separator } from "@/components/ui/separator";

export function MobileNav({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const { t } = useLanguage();

  const links = [
    { href: "/", label: t("nav_home") },
    { href: "/shop", label: t("nav_shop") },
    { href: "/shop?filter=new", label: t("nav_new_drops") },
    { href: "/journal", label: t("nav_journal") },
    { href: "/about", label: t("nav_about") },
  ];

  return (
    <Sheet open={open} onOpenChange={onOpenChange} side="left" title="Menu">
      <nav className="flex flex-col">
        {links.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            onClick={() => onOpenChange(false)}
            className="border-b border-border py-3.5 text-base font-medium"
          >
            {link.label}
          </Link>
        ))}
      </nav>
      <Separator className="my-6" />
      <p className="mb-3 text-xs font-medium uppercase tracking-wide text-muted-foreground">Region &amp; Language</p>
      <CurrencyLanguageToggle />
    </Sheet>
  );
}
