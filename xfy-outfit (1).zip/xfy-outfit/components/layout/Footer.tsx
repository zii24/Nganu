"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Logo } from "@/components/shared/Logo";
import { Instagram, MessageCircle } from "lucide-react";

export function Footer() {
  const pathname = usePathname();
  if (pathname?.startsWith("/admin")) return null;

  return (
    <footer className="border-t border-border bg-background">
      <div className="container py-14">
        <div className="grid grid-cols-2 gap-8 sm:grid-cols-4 lg:grid-cols-5">
          <div className="col-span-2 lg:col-span-2">
            <Logo className="text-lg" />
            <p className="mt-3 max-w-xs text-sm text-muted-foreground">
              Curated second-hand fashion from Indonesia — inspected, measured, and graded before it reaches you.
            </p>
            <div className="mt-5 flex items-center gap-3">
              <a href="#" aria-label="Instagram" className="flex h-9 w-9 items-center justify-center border border-border hover:border-foreground/40">
                <Instagram className="h-4 w-4" strokeWidth={1.5} />
              </a>
              <a href="#" aria-label="WhatsApp" className="flex h-9 w-9 items-center justify-center border border-border hover:border-foreground/40">
                <MessageCircle className="h-4 w-4" strokeWidth={1.5} />
              </a>
            </div>
          </div>

          <div>
            <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Shop</p>
            <ul className="mt-3 space-y-2.5 text-sm">
              <li><Link href="/shop" className="hover:text-primary">All Products</Link></li>
              <li><Link href="/shop?filter=new" className="hover:text-primary">New Drops</Link></li>
              <li><Link href="/wishlist" className="hover:text-primary">Wishlist</Link></li>
            </ul>
          </div>

          <div>
            <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">XFY</p>
            <ul className="mt-3 space-y-2.5 text-sm">
              <li><Link href="/about" className="hover:text-primary">About</Link></li>
              <li><Link href="/journal" className="hover:text-primary">Journal</Link></li>
              <li><Link href="/about#buyer-protection" className="hover:text-primary">Buyer Protection</Link></li>
              <li><Link href="/about#sell" className="hover:text-primary">Sell With XFY</Link></li>
            </ul>
          </div>

          <div>
            <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Support</p>
            <ul className="mt-3 space-y-2.5 text-sm">
              <li><a href="https://wa.me/6281234567890" target="_blank" rel="noreferrer" className="hover:text-primary">WhatsApp Support</a></li>
              <li><Link href="/about#shipping" className="hover:text-primary">Shipping Info</Link></li>
              <li><Link href="/about#returns" className="hover:text-primary">Returns Policy</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col gap-3 border-t border-border pt-6 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <p>&copy; {new Date().getFullYear()} XFY Outfit. Ships from Indonesia.</p>
          <p>This is a frontend prototype — no live payments are processed.</p>
        </div>
      </div>
    </footer>
  );
}
