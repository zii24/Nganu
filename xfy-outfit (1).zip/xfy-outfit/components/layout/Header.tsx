"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Search, Heart, ShoppingBag, Menu, User } from "lucide-react";
import { Logo } from "@/components/shared/Logo";
import { CurrencyLanguageToggle } from "./CurrencyLanguageToggle";
import { SearchDialog } from "./SearchDialog";
import { MobileNav } from "./MobileNav";
import { useWishlist } from "@/context/WishlistContext";
import { useCart } from "@/context/CartContext";
import { useLanguage } from "@/context/LanguageContext";
import { cn } from "@/lib/utils";

export function Header() {
  const [searchOpen, setSearchOpen] = useState(false);
  const [navOpen, setNavOpen] = useState(false);
  const { ids: wishlistIds, hydrated: wishlistHydrated } = useWishlist();
  const { ids: cartIds, hydrated: cartHydrated } = useCart();
  const { t } = useLanguage();
  const pathname = usePathname();

  const links = [
    { href: "/", label: t("nav_home") },
    { href: "/shop", label: t("nav_shop") },
    { href: "/shop?filter=new", label: t("nav_new_drops") },
    { href: "/journal", label: t("nav_journal") },
    { href: "/about", label: t("nav_about") },
  ];

  const isAdmin = pathname?.startsWith("/admin");
  if (isAdmin) return null;

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur-sm">
      <div className="container flex h-16 items-center justify-between gap-4 sm:h-[72px]">
        <div className="flex items-center gap-3">
          <button
            className="flex h-9 w-9 items-center justify-center lg:hidden"
            onClick={() => setNavOpen(true)}
            aria-label="Open menu"
          >
            <Menu className="h-5 w-5" />
          </button>
          <Link href="/" className="text-lg">
            <Logo />
          </Link>
        </div>

        <nav className="hidden items-center gap-7 lg:flex">
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="text-sm font-medium text-foreground/80 transition-colors hover:text-foreground"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-1 sm:gap-2">
          <div className="hidden md:block">
            <CurrencyLanguageToggle className="mr-2" />
          </div>
          <button
            onClick={() => setSearchOpen(true)}
            aria-label="Search"
            className="flex h-9 w-9 items-center justify-center hover:text-primary"
          >
            <Search className="h-[18px] w-[18px]" strokeWidth={1.5} />
          </button>
          <Link
            href="/wishlist"
            aria-label="Wishlist"
            className="relative flex h-9 w-9 items-center justify-center hover:text-primary"
          >
            <Heart className="h-[18px] w-[18px]" strokeWidth={1.5} />
            {wishlistHydrated && wishlistIds.length > 0 && (
              <span className="absolute right-0.5 top-0.5 flex h-4 min-w-4 items-center justify-center bg-primary px-0.5 text-[10px] font-semibold text-primary-foreground rounded-full">
                {wishlistIds.length}
              </span>
            )}
          </Link>
          <Link
            href="/cart"
            aria-label="Cart"
            className="relative flex h-9 w-9 items-center justify-center hover:text-primary"
          >
            <ShoppingBag className="h-[18px] w-[18px]" strokeWidth={1.5} />
            {cartHydrated && cartIds.length > 0 && (
              <span className="absolute right-0.5 top-0.5 flex h-4 min-w-4 items-center justify-center bg-primary px-0.5 text-[10px] font-semibold text-primary-foreground rounded-full">
                {cartIds.length}
              </span>
            )}
          </Link>
          <button
            aria-label="Account"
            title="Account — coming soon"
            className={cn("hidden h-9 w-9 items-center justify-center hover:text-primary sm:flex")}
          >
            <User className="h-[18px] w-[18px]" strokeWidth={1.5} />
          </button>
        </div>
      </div>

      <SearchDialog open={searchOpen} onOpenChange={setSearchOpen} />
      <MobileNav open={navOpen} onOpenChange={setNavOpen} />
    </header>
  );
}
