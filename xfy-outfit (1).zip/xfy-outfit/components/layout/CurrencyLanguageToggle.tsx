"use client";

import { useCurrency } from "@/context/CurrencyContext";
import { useLanguage } from "@/context/LanguageContext";
import { cn } from "@/lib/utils";

function ToggleGroup<T extends string>({
  value,
  options,
  onChange,
}: {
  value: T;
  options: { label: string; value: T }[];
  onChange: (v: T) => void;
}) {
  return (
    <div className="inline-flex items-center border border-border text-xs font-medium rounded-sm">
      {options.map((opt) => (
        <button
          key={opt.value}
          onClick={() => onChange(opt.value)}
          className={cn(
            "px-2.5 py-1.5 transition-colors",
            value === opt.value ? "bg-foreground text-background" : "text-muted-foreground hover:text-foreground"
          )}
        >
          {opt.label}
        </button>
      ))}
    </div>
  );
}

export function CurrencyLanguageToggle({ className }: { className?: string }) {
  const { currency, setCurrency } = useCurrency();
  const { locale, setLocale } = useLanguage();

  return (
    <div className={cn("flex items-center gap-2", className)}>
      <ToggleGroup
        value={locale}
        onChange={setLocale}
        options={[
          { label: "EN", value: "en" },
          { label: "ID", value: "id" },
        ]}
      />
      <ToggleGroup
        value={currency}
        onChange={setCurrency}
        options={[
          { label: "IDR", value: "IDR" },
          { label: "USD", value: "USD" },
        ]}
      />
    </div>
  );
}
