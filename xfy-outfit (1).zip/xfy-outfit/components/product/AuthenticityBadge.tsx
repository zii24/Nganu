import { BadgeCheck, HelpCircle, TriangleAlert } from "lucide-react";
import type { AuthenticityStatus } from "@/lib/types";
import { cn } from "@/lib/utils";

const CONFIG: Record<
  AuthenticityStatus,
  { icon: typeof BadgeCheck; label: string; sub: string; tone: string }
> = {
  Original: {
    icon: BadgeCheck,
    label: "Original Product",
    sub: "Checked by XFY's inspection team against known reference details.",
    tone: "text-success",
  },
  "Not Verified": {
    icon: HelpCircle,
    label: "Authenticity Not Verified",
    sub: "XFY has not been able to confirm authenticity for this piece. Listed with full disclosure.",
    tone: "text-muted-foreground",
  },
  "Not Original": {
    icon: TriangleAlert,
    label: "Not an Original Product",
    sub: "This item has been identified as not authentic and is priced and disclosed accordingly.",
    tone: "text-destructive",
  },
};

export function AuthenticityBadge({ status }: { status: AuthenticityStatus }) {
  const { icon: Icon, label, sub, tone } = CONFIG[status];

  return (
    <div className="flex items-start gap-3 border border-border p-4">
      <Icon className={cn("mt-0.5 h-5 w-5 shrink-0", tone)} strokeWidth={1.5} />
      <div>
        <p className={cn("text-sm font-medium", tone)}>{label}</p>
        <p className="mt-1 text-sm text-muted-foreground">{sub}</p>
      </div>
    </div>
  );
}
