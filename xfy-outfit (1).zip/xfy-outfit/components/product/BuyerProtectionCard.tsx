import Link from "next/link";
import { ShieldCheck, ArrowRight } from "lucide-react";

export function BuyerProtectionCard() {
  return (
    <div className="border border-border p-4">
      <div className="flex items-start gap-3">
        <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-primary" strokeWidth={1.5} />
        <div>
          <p className="text-sm font-medium">Covered by XFY Buyer Protection</p>
          <p className="mt-1 text-sm text-muted-foreground">
            Eligible for wrong item, undisclosed condition, or authenticity issues. Return window: 7 days after
            delivery.
          </p>
          <Link
            href="/about#buyer-protection"
            className="mt-2 inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline"
          >
            See full coverage <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>
      </div>
    </div>
  );
}
