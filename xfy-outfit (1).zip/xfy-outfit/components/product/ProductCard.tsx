"use client";

import Link from "next/link";
import Image from "next/image";
import { Heart } from "lucide-react";
import type { Product } from "@/lib/types";
import { CONDITION_LABEL } from "@/lib/types";
import { isNewDrop, cn } from "@/lib/utils";
import { Price } from "@/components/shared/Price";
import { useWishlist } from "@/context/WishlistContext";

export function ProductCard({ product, className }: { product: Product; className?: string }) {
  const { isWishlisted, toggle, hydrated } = useWishlist();
  const wishlisted = hydrated && isWishlisted(product.id);
  const newDrop = isNewDrop(product.publishedAt);
  const unavailable = product.inventoryStatus === "Sold" || product.inventoryStatus === "Reserved";
  const frontImage = product.images.find((i) => i.kind === "front") ?? product.images[0];

  return (
    <div className={cn("group relative", className)}>
      <Link href={`/product/${product.slug}`} className="block">
        <div className="relative aspect-[4/5] overflow-hidden bg-secondary">
          <Image
            src={frontImage.url}
            alt={frontImage.alt}
            fill
            sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
            className={cn(
              "object-cover transition-opacity duration-300",
              unavailable ? "opacity-50" : "group-hover:opacity-90"
            )}
          />
          <div className="absolute left-2.5 top-2.5 flex flex-col gap-1.5">
            {newDrop && (
              <span className="bg-primary px-2 py-1 text-[10px] font-semibold uppercase tracking-wider text-primary-foreground">
                New Drop
              </span>
            )}
            {product.inventoryStatus === "Reserved" && (
              <span className="bg-foreground px-2 py-1 text-[10px] font-semibold uppercase tracking-wider text-background">
                Reserved
              </span>
            )}
            {product.inventoryStatus === "Sold" && (
              <span className="bg-foreground px-2 py-1 text-[10px] font-semibold uppercase tracking-wider text-background">
                Sold
              </span>
            )}
          </div>
        </div>
      </Link>
      <button
        type="button"
        aria-label={wishlisted ? "Remove from wishlist" : "Save to wishlist"}
        onClick={(e) => {
          e.preventDefault();
          toggle(product.id);
        }}
        className="absolute right-2.5 top-2.5 flex h-8 w-8 items-center justify-center bg-background/90 text-foreground backdrop-blur-sm hover:bg-background"
      >
        <Heart className={cn("h-4 w-4", wishlisted && "fill-foreground")} strokeWidth={1.5} />
      </button>

      <Link href={`/product/${product.slug}`} className="mt-3 block">
        <p className="text-xs text-muted-foreground">{product.brand}</p>
        <p className="mt-0.5 truncate text-sm font-medium">{product.name}</p>
        <div className="mt-1 flex items-center justify-between gap-2">
          <p className="text-xs text-muted-foreground">
            {CONDITION_LABEL[product.condition]} · {product.size}
          </p>
        </div>
        <Price idr={product.priceIdr} usd={product.priceUsd} className="mt-1.5 text-sm font-medium" />
      </Link>
    </div>
  );
}
