import type { Measurements } from "@/lib/types";

const LABELS: Record<keyof Measurements, string> = {
  length: "Length",
  width: "Width",
  chestWidth: "Chest Width",
  shoulder: "Shoulder",
  sleeve: "Sleeve",
  waist: "Waist",
  rise: "Rise",
  inseam: "Inseam",
  legOpening: "Leg Opening",
};

export function MeasurementsTable({ measurements }: { measurements: Measurements }) {
  const entries = (Object.keys(LABELS) as (keyof Measurements)[]).filter((key) => measurements[key] !== undefined);

  if (entries.length === 0) {
    return <p className="text-sm text-muted-foreground">No measurements recorded for this item yet.</p>;
  }

  return (
    <div>
      <div className="grid grid-cols-2 gap-x-6 gap-y-3 sm:grid-cols-3">
        {entries.map((key) => (
          <div key={key} className="flex items-baseline justify-between border-b border-border pb-2 sm:flex-col sm:items-start sm:gap-0.5 sm:border-none sm:pb-0">
            <span className="text-xs text-muted-foreground">{LABELS[key]}</span>
            <span className="text-sm font-medium">{measurements[key]} cm</span>
          </div>
        ))}
      </div>
      <p className="mt-4 text-xs text-muted-foreground">
        Measured flat, by hand. Allow ±1–2 cm variance, typical for pre-owned garments.
      </p>
    </div>
  );
}
