"use client";

import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select } from "@/components/ui/select";
import { getEnabledRegions } from "@/lib/mock-shipping";
import { formatAmount } from "@/lib/utils";
import { useCurrency } from "@/context/CurrencyContext";
import { Truck } from "lucide-react";

export function ShippingModal({
  open,
  onOpenChange,
  shippingFrom,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  shippingFrom: string;
}) {
  const regions = getEnabledRegions();
  const [regionId, setRegionId] = useState(regions[0]?.id ?? "id");
  const { currency } = useCurrency();
  const region = regions.find((r) => r.id === regionId) ?? regions[0];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent onClose={() => onOpenChange(false)} className="max-w-md">
        <DialogHeader>
          <DialogTitle>Shipping &amp; Delivery</DialogTitle>
          <p className="mt-1.5 flex items-center gap-1.5 text-sm text-muted-foreground">
            <Truck className="h-3.5 w-3.5" /> Ships from {shippingFrom}
          </p>
        </DialogHeader>

        <label className="mb-1.5 block text-xs font-medium text-muted-foreground">Destination</label>
        <Select value={regionId} onChange={(e) => setRegionId(e.target.value)}>
          {regions.map((r) => (
            <option key={r.id} value={r.id}>
              {r.name}
            </option>
          ))}
        </Select>

        {region && (
          <div className="mt-5 space-y-3 border border-border p-4">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Shipping fee</span>
              <span className="font-medium">{formatAmount(currency === "IDR" ? region.feeIdr : region.feeUsd, currency)}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Estimated delivery</span>
              <span className="font-medium">
                {region.minDays}–{region.maxDays} business days
              </span>
            </div>
          </div>
        )}

        <p className="mt-4 text-xs leading-relaxed text-muted-foreground">
          Rates and delivery windows are configurable estimates, not guaranteed courier commitments. Delivery
          time begins once XFY inspection is complete and the item ships.
        </p>
      </DialogContent>
    </Dialog>
  );
}
