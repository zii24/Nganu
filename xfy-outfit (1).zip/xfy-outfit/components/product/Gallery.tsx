"use client";

import { useState } from "react";
import Image from "next/image";
import type { ProductImage } from "@/lib/types";
import { cn } from "@/lib/utils";

const KIND_LABEL: Record<ProductImage["kind"], string> = {
  front: "Front",
  back: "Back",
  tag: "Brand Tag",
  wash_tag: "Wash Tag",
  detail: "Detail",
  defect: "Condition Note",
};

export function Gallery({ images }: { images: ProductImage[] }) {
  const [active, setActive] = useState(0);
  const current = images[active] ?? images[0];

  return (
    <div className="flex flex-col-reverse gap-3 sm:flex-row">
      <div className="flex gap-2 overflow-x-auto sm:w-[76px] sm:flex-col sm:overflow-visible">
        {images.map((image, i) => (
          <button
            key={image.url + image.kind}
            onClick={() => setActive(i)}
            className={cn(
              "relative aspect-[4/5] w-16 shrink-0 overflow-hidden border sm:w-full",
              i === active ? "border-foreground" : "border-border hover:border-foreground/40"
            )}
            aria-label={`Show ${KIND_LABEL[image.kind]} image`}
          >
            <Image src={image.url} alt={image.alt} fill sizes="80px" className="object-cover" />
          </button>
        ))}
      </div>

      <div className="relative flex-1">
        <div className="relative aspect-[4/5] w-full overflow-hidden bg-secondary">
          <Image
            key={current.url}
            src={current.url}
            alt={current.alt}
            fill
            priority
            sizes="(max-width: 640px) 100vw, 50vw"
            className="object-cover"
          />
        </div>
        <span className="absolute bottom-3 left-3 bg-background/90 px-2 py-1 text-[11px] font-medium">
          {KIND_LABEL[current.kind]}
        </span>
      </div>
    </div>
  );
}
