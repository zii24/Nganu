import type { Product } from "@/lib/types";
import { ProductCard } from "./ProductCard";
import { EmptyState } from "@/components/shared/EmptyState";
import { SearchX } from "lucide-react";
import { cn } from "@/lib/utils";

export function ProductGrid({
  products,
  className,
  emptyTitle = "No items match these filters",
  emptyDescription = "Try adjusting or clearing your filters to see more pieces.",
}: {
  products: Product[];
  className?: string;
  emptyTitle?: string;
  emptyDescription?: string;
}) {
  if (products.length === 0) {
    return <EmptyState icon={SearchX} title={emptyTitle} description={emptyDescription} />;
  }

  return (
    <div className={cn("grid grid-cols-2 gap-x-4 gap-y-9 sm:grid-cols-3 lg:grid-cols-4", className)}>
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}
