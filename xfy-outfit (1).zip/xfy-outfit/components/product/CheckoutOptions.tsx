"use client";

import { useRouter } from "next/navigation";
import { ArrowUpRight } from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";
import { useCart } from "@/context/CartContext";
import type { Product } from "@/lib/types";
import { cn } from "@/lib/utils";

export function CheckoutOptions({
  product,
  productId,
  disabled,
}: {
  product: Pick<Product, "shopeeUrl" | "grailedUrl" | "inventoryStatus">;
  productId: string;
  disabled?: boolean;
}) {
  const { t } = useLanguage();
  const { add } = useCart();
  const router = useRouter();

  function handleBuyNow() {
    if (disabled) return;
    add(productId);
    router.push("/checkout");
  }

  return (
    <div className="space-y-2.5">
      <button
        type="button"
        onClick={handleBuyNow}
        disabled={disabled}
        className={cn(
          "flex h-12 w-full items-center justify-center bg-primary text-sm font-medium text-primary-foreground rounded-sm",
          disabled ? "pointer-events-none opacity-40" : "hover:bg-primary/90"
        )}
      >
        {t("buy_on_xfy")}
      </button>

      {product.shopeeUrl && (
        <a
          href={disabled ? undefined : product.shopeeUrl}
          target="_blank"
          rel="noreferrer"
          aria-disabled={disabled}
          className={cn(
            "flex h-12 w-full items-center justify-center gap-1.5 border border-border text-sm font-medium rounded-sm",
            disabled ? "pointer-events-none opacity-40" : "hover:border-foreground/40"
          )}
        >
          {t("buy_on_shopee")}
          <ArrowUpRight className="h-3.5 w-3.5" />
        </a>
      )}

      {product.grailedUrl && (
        <a
          href={disabled ? undefined : product.grailedUrl}
          target="_blank"
          rel="noreferrer"
          aria-disabled={disabled}
          className={cn(
            "flex h-12 w-full items-center justify-center gap-1.5 border border-border text-sm font-medium rounded-sm",
            disabled ? "pointer-events-none opacity-40" : "hover:border-foreground/40"
          )}
        >
          {t("buy_on_grailed")}
          <ArrowUpRight className="h-3.5 w-3.5" />
        </a>
      )}

      {(product.shopeeUrl || product.grailedUrl) && (
        <p className="pt-1 text-center text-xs text-muted-foreground">{t("external_checkout")}</p>
      )}
    </div>
  );
}
