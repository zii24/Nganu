"use client";

import { useState } from "react";
import { Info } from "lucide-react";
import type { ConditionScore } from "@/lib/types";
import { CONDITION_LABEL } from "@/lib/types";
import { ConditionModal } from "./ConditionModal";
import { cn } from "@/lib/utils";

export function ConditionBadge({
  score,
  notes = [],
  className,
  size = "default",
}: {
  score: ConditionScore;
  notes?: string[];
  className?: string;
  size?: "default" | "sm";
}) {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className={cn(
          "inline-flex items-center gap-1.5 border border-foreground/20 px-2.5 py-1 font-medium hover:border-foreground/40 rounded-sm",
          size === "sm" ? "text-[11px]" : "text-xs",
          className
        )}
      >
        <span>
          {score}/10 · {CONDITION_LABEL[score]}
        </span>
        <Info className="h-3 w-3 text-muted-foreground" />
      </button>
      <ConditionModal open={open} onOpenChange={setOpen} score={score} notes={notes} />
    </>
  );
}
