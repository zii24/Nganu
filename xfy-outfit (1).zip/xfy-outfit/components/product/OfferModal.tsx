"use client";

import { useState, FormEvent } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { formatAmount } from "@/lib/utils";
import { useCurrency } from "@/context/CurrencyContext";
import type { Product } from "@/lib/types";
import { Clock, CircleCheck, CircleX } from "lucide-react";

type OfferOutcome = "auto-rejected" | "pending-review";

export function OfferModal({
  open,
  onOpenChange,
  product,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  product: Product;
}) {
  const { currency } = useCurrency();
  const [amount, setAmount] = useState("");
  const [outcome, setOutcome] = useState<OfferOutcome | null>(null);
  const listingPrice = currency === "IDR" ? product.priceIdr : product.priceUsd;

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const value = Number(amount);
    if (!value || value <= 0) return;

    // NOTE: this evaluation runs client-side only because this build has no
    // backend yet. In production this must move to a server route so the
    // minimum offer value is never present in client-side data at all.
    const minimum = currency === "IDR" ? product.minimumOfferIdr : product.minimumOfferUsd;
    setOutcome(value >= minimum ? "pending-review" : "auto-rejected");
  }

  function handleClose(open: boolean) {
    onOpenChange(open);
    if (!open) {
      setAmount("");
      setOutcome(null);
    }
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent onClose={() => handleClose(false)} className="max-w-sm">
        <DialogHeader>
          <DialogTitle>Make an Offer</DialogTitle>
          <p className="mt-1.5 text-sm text-muted-foreground">
            Listing price: <span className="font-medium text-foreground">{formatAmount(listingPrice, currency)}</span>
          </p>
        </DialogHeader>

        {outcome === null && (
          <form onSubmit={handleSubmit}>
            <label className="mb-1.5 block text-xs font-medium text-muted-foreground">Your offer ({currency})</label>
            <Input
              type="number"
              inputMode="numeric"
              min={1}
              required
              autoFocus
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder={currency === "IDR" ? "e.g. 400000" : "e.g. 26"}
            />
            <p className="mt-2 text-xs text-muted-foreground">
              Offers are reviewed against the seller's floor. You'll hear back within 24 hours, or your offer expires
              automatically.
            </p>
            <Button type="submit" className="mt-5 w-full">
              Submit Offer
            </Button>
          </form>
        )}

        {outcome === "pending-review" && (
          <div className="flex flex-col items-center py-4 text-center">
            <Clock className="h-8 w-8 text-primary" strokeWidth={1.5} />
            <p className="mt-3 text-sm font-medium">Offer submitted</p>
            <p className="mt-1.5 text-sm text-muted-foreground">
              Your offer of {formatAmount(Number(amount), currency)} is with the XFY team for review. It expires in
              24 hours if there's no response — we'll notify you either way.
            </p>
            <Button variant="outline" className="mt-5" onClick={() => handleClose(false)}>
              Done
            </Button>
          </div>
        )}

        {outcome === "auto-rejected" && (
          <div className="flex flex-col items-center py-4 text-center">
            <CircleX className="h-8 w-8 text-destructive" strokeWidth={1.5} />
            <p className="mt-3 text-sm font-medium">Offer not accepted</p>
            <p className="mt-1.5 text-sm text-muted-foreground">
              That offer is below what the seller will consider for this piece. Try a higher offer, or buy at the
              listing price.
            </p>
            <Button variant="outline" className="mt-5" onClick={() => setOutcome(null)}>
              Try Again
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
