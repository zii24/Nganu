"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Heart, Share2, Check, ChevronRight, ShoppingBag } from "lucide-react";
import type { Product } from "@/lib/types";
import { Price } from "@/components/shared/Price";
import { Gallery } from "./Gallery";
import { ConditionBadge } from "./ConditionBadge";
import { MeasurementsTable } from "./MeasurementsTable";
import { AuthenticityBadge } from "./AuthenticityBadge";
import { ShippingModal } from "./ShippingModal";
import { OfferModal } from "./OfferModal";
import { CheckoutOptions } from "./CheckoutOptions";
import { BuyerProtectionCard } from "./BuyerProtectionCard";
import { ProductGrid } from "./ProductGrid";
import { SectionHeading } from "@/components/shared/SectionHeading";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useWishlist } from "@/context/WishlistContext";
import { useRecentlyViewed } from "@/context/RecentlyViewedContext";
import { useCart } from "@/context/CartContext";
import { useLanguage } from "@/context/LanguageContext";
import { getRelatedProducts } from "@/lib/mock-data";
import { isPurchasable } from "@/lib/utils";

export function ProductDetailContent({ product }: { product: Product }) {
  const { isWishlisted, toggle, hydrated: wishlistHydrated } = useWishlist();
  const { record } = useRecentlyViewed();
  const { add, has, hydrated: cartHydrated } = useCart();
  const { locale, t } = useLanguage();

  const [shippingOpen, setShippingOpen] = useState(false);
  const [offerOpen, setOfferOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [added, setAdded] = useState(false);

  useEffect(() => {
    record(product.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [product.id]);

  const purchasable = isPurchasable(product.inventoryStatus);
  const inCart = cartHydrated && has(product.id);
  const wishlisted = wishlistHydrated && isWishlisted(product.id);
  const related = getRelatedProducts(product, 4);

  function handleShare() {
    const url = typeof window !== "undefined" ? window.location.href : "";
    if (navigator.share) {
      navigator.share({ title: product.name, url }).catch(() => {});
      return;
    }
    navigator.clipboard?.writeText(url).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    });
  }

  function handleAddToCart() {
    if (!purchasable) return;
    add(product.id);
    setAdded(true);
    setTimeout(() => setAdded(false), 1800);
  }

  return (
    <div className="container py-6 lg:py-10">
      <nav className="mb-6 flex items-center gap-1.5 text-xs text-muted-foreground">
        <Link href="/shop" className="hover:text-foreground">
          Shop
        </Link>
        <ChevronRight className="h-3 w-3" />
        <Link href={`/shop?category=${encodeURIComponent(product.category)}`} className="hover:text-foreground">
          {product.category}
        </Link>
        <ChevronRight className="h-3 w-3" />
        <span className="text-foreground">{product.name}</span>
      </nav>

      <div className="grid grid-cols-1 gap-10 lg:grid-cols-2 lg:gap-14">
        <Gallery images={product.images} />

        <div className="lg:max-w-md">
          {!purchasable && (
            <Badge variant={product.inventoryStatus === "Sold" ? "default" : "muted"} className="mb-3">
              {product.inventoryStatus === "Sold" ? "Sold" : "Reserved — pending checkout"}
            </Badge>
          )}
          <p className="text-sm text-muted-foreground">{product.brand}</p>
          <h1 className="mt-1 text-2xl font-medium tracking-tight sm:text-[26px]">{product.name}</h1>

          <div className="mt-3 flex items-center gap-3">
            <Price idr={product.priceIdr} usd={product.priceUsd} className="text-xl font-medium" />
            <ConditionBadge score={product.condition} notes={product.conditionNotes} />
          </div>

          <div className="mt-5 grid grid-cols-2 gap-4 border-y border-border py-4 text-sm">
            <div>
              <p className="text-xs text-muted-foreground">Color</p>
              <p className="mt-0.5 font-medium">{product.color}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Size</p>
              <p className="mt-0.5 font-medium">{product.size}</p>
            </div>
          </div>

          <div className="mt-5 flex items-center gap-2">
            <button
              onClick={() => toggle(product.id)}
              className="flex h-10 flex-1 items-center justify-center gap-2 border border-border text-sm font-medium hover:border-foreground/40"
            >
              <Heart className={wishlisted ? "h-4 w-4 fill-foreground" : "h-4 w-4"} strokeWidth={1.5} />
              {wishlisted ? "Saved" : t("save_to_wishlist")}
            </button>
            <button
              onClick={handleShare}
              className="flex h-10 flex-1 items-center justify-center gap-2 border border-border text-sm font-medium hover:border-foreground/40"
            >
              {copied ? <Check className="h-4 w-4" /> : <Share2 className="h-4 w-4" strokeWidth={1.5} />}
              {copied ? "Copied" : t("share")}
            </button>
          </div>

          <div className="mt-4">
            <Button
              variant={inCart ? "secondary" : "outline"}
              className="w-full"
              onClick={handleAddToCart}
              disabled={!purchasable}
            >
              <ShoppingBag className="h-4 w-4" strokeWidth={1.5} />
              {added || inCart ? "Added to Cart" : t("add_to_cart")}
            </Button>
            <button
              onClick={() => setOfferOpen(true)}
              disabled={!purchasable}
              className="mt-2.5 w-full text-center text-sm font-medium text-foreground underline underline-offset-4 decoration-foreground/30 hover:decoration-foreground disabled:pointer-events-none disabled:opacity-40"
            >
              {t("make_offer")}
            </button>
          </div>

          <div className="mt-6">
            <p className="mb-2.5 text-xs font-medium uppercase tracking-wide text-muted-foreground">
              {t("checkout_options")}
            </p>
            <CheckoutOptions product={product} productId={product.id} disabled={!purchasable} />
          </div>

          <button
            onClick={() => setShippingOpen(true)}
            className="mt-6 flex w-full items-center justify-between border border-border px-4 py-3 text-left text-sm hover:border-foreground/40"
          >
            <span>
              <span className="font-medium">Ships from {product.shippingFrom}</span>
              <span className="block text-xs text-muted-foreground">See fees &amp; delivery estimates</span>
            </span>
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
          </button>

          <div className="mt-4">
            <BuyerProtectionCard />
          </div>
        </div>
      </div>

      <div className="mt-14 grid grid-cols-1 gap-10 lg:grid-cols-2 lg:gap-14">
        <div>
          <h2 className="mb-3 text-lg font-medium">{t("description")}</h2>
          <p className="text-sm leading-relaxed text-muted-foreground">
            {locale === "id" ? product.descriptionId : product.descriptionEn}
          </p>

          <h2 className="mb-3 mt-8 text-lg font-medium">{t("condition_details")}</h2>
          {product.conditionNotes.length > 0 ? (
            <ul className="space-y-2">
              {product.conditionNotes.map((note, i) => (
                <li key={i} className="flex gap-2 text-sm text-muted-foreground">
                  <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-muted-foreground" />
                  {note}
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm text-muted-foreground">No condition notes — inspected with no flaws found.</p>
          )}
        </div>

        <div>
          <h2 className="mb-3 text-lg font-medium">{t("measurements")}</h2>
          <MeasurementsTable measurements={product.measurements} />

          <h2 className="mb-3 mt-8 text-lg font-medium">{t("authenticity")}</h2>
          <AuthenticityBadge status={product.authenticity} />
        </div>
      </div>

      {related.length > 0 && (
        <section className="mt-16 border-t border-border pt-12">
          <SectionHeading title={t("you_might_also_like")} />
          <ProductGrid products={related} />
        </section>
      )}

      <ShippingModal open={shippingOpen} onOpenChange={setShippingOpen} shippingFrom={product.shippingFrom} />
      <OfferModal open={offerOpen} onOpenChange={setOfferOpen} product={product} />
    </div>
  );
}
