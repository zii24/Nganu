"use client";

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import type { ConditionScore } from "@/lib/types";
import { CONDITION_LABEL } from "@/lib/types";
import { cn } from "@/lib/utils";

const TIERS: { score: ConditionScore; description: string }[] = [
  { score: 10, description: "No visible flaws on inspection. Feels unworn or deadstock." },
  { score: 9, description: "Worn a handful of times. Only very minor, easy-to-miss marks." },
  { score: 8, description: "Light, honest signs of wear — minor pilling, small marks, nothing structural." },
  { score: 7, description: "Noticeable wear consistent with age: fading, small marks, or a minor flaw called out in photos." },
  { score: 6, description: "Well-worn with visible flaws (stains, holes, or heavy fading), priced and disclosed accordingly." },
];

export function ConditionModal({
  open,
  onOpenChange,
  score,
  notes = [],
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  score: ConditionScore;
  notes?: string[];
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent onClose={() => onOpenChange(false)} className="max-w-xl">
        <DialogHeader>
          <DialogTitle>How XFY grades condition</DialogTitle>
          <p className="mt-1.5 text-sm text-muted-foreground">
            Every item is inspected in person and scored on a fixed 1–10 scale before it's listed. Scores are
            never rounded up.
          </p>
        </DialogHeader>

        <div className="divide-y divide-border">
          {TIERS.map((tier) => (
            <div
              key={tier.score}
              className={cn("flex gap-4 py-3", tier.score === score && "bg-secondary/60 -mx-2 px-2")}
            >
              <div className="w-24 shrink-0 pt-0.5 text-sm font-medium">
                {tier.score}/10
                {tier.score === score && <span className="ml-1.5 text-primary">•</span>}
              </div>
              <div>
                <p className="text-sm font-medium">{CONDITION_LABEL[tier.score]}</p>
                <p className="mt-0.5 text-sm text-muted-foreground">{tier.description}</p>
              </div>
            </div>
          ))}
        </div>

        {notes.length > 0 && (
          <div className="mt-5 border border-border p-4">
            <p className="text-sm font-medium">Specific to this item</p>
            <ul className="mt-2 space-y-1.5">
              {notes.map((note, i) => (
                <li key={i} className="flex gap-2 text-sm text-muted-foreground">
                  <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-muted-foreground" />
                  {note}
                </li>
              ))}
            </ul>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
