import { cn } from "@/lib/utils";
import Link from "next/link";

export function SectionHeading({
  title,
  subtitle,
  viewAllHref,
  viewAllLabel = "View All",
  className,
}: {
  title: string;
  subtitle?: string;
  viewAllHref?: string;
  viewAllLabel?: string;
  className?: string;
}) {
  return (
    <div className={cn("mb-7 flex items-end justify-between gap-6", className)}>
      <div>
        <h2 className="text-2xl font-medium tracking-tight sm:text-[28px]">{title}</h2>
        {subtitle && <p className="mt-1.5 text-sm text-muted-foreground">{subtitle}</p>}
      </div>
      {viewAllHref && (
        <Link href={viewAllHref} className="shrink-0 text-sm font-medium text-foreground underline underline-offset-4 decoration-foreground/30 hover:decoration-foreground">
          {viewAllLabel}
        </Link>
      )}
    </div>
  );
}
