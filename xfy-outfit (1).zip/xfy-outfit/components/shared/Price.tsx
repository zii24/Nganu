"use client";

import { useCurrency } from "@/context/CurrencyContext";
import { formatAmount, cn } from "@/lib/utils";

export function Price({
  idr,
  usd,
  className,
  strikeIdr,
  strikeUsd,
}: {
  idr: number;
  usd: number;
  className?: string;
  strikeIdr?: number;
  strikeUsd?: number;
}) {
  const { currency } = useCurrency();
  const amount = currency === "IDR" ? idr : usd;
  const strike = currency === "IDR" ? strikeIdr : strikeUsd;

  return (
    <span className={cn("inline-flex items-baseline gap-2", className)}>
      <span>{formatAmount(amount, currency)}</span>
      {strike && strike > amount && (
        <span className="text-muted-foreground line-through text-[0.85em]">{formatAmount(strike, currency)}</span>
      )}
    </span>
  );
}
