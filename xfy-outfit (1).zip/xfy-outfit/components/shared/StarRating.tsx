"use client";

import { Star } from "lucide-react";
import { cn } from "@/lib/utils";

export function StarRating({
  value,
  onChange,
  size = 18,
  readOnly = false,
  className,
}: {
  value: number;
  onChange?: (v: number) => void;
  size?: number;
  readOnly?: boolean;
  className?: string;
}) {
  return (
    <div className={cn("inline-flex items-center gap-1", className)}>
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          type="button"
          disabled={readOnly}
          onClick={() => onChange?.(star)}
          aria-label={`${star} star${star > 1 ? "s" : ""}`}
          className={cn(!readOnly && "cursor-pointer")}
        >
          <Star
            width={size}
            height={size}
            className={star <= value ? "fill-foreground text-foreground" : "fill-transparent text-muted-foreground"}
            strokeWidth={1.5}
          />
        </button>
      ))}
    </div>
  );
}
