"use client";

import { ShieldCheck, PackageX, SearchX, BadgeAlert, TriangleAlert, Clock } from "lucide-react";
import { AccordionItem, Accordion } from "@/components/ui/accordion";

const CASES = [
  {
    icon: PackageX,
    title: "Item materially differs from its description",
    body: "The piece you received doesn't match what was described — different fabric, color, print, or era than listed.",
  },
  {
    icon: SearchX,
    title: "Wrong item received",
    body: "You received a different product than the one you purchased.",
  },
  {
    icon: BadgeAlert,
    title: "Material inspection issue",
    body: "A condition-affecting flaw wasn't disclosed in the listing's condition score or notes.",
  },
  {
    icon: TriangleAlert,
    title: "Authenticity concern",
    body: "You have reason to believe an item marked Original does not match its stated authenticity status.",
  },
  {
    icon: ShieldCheck,
    title: "Significant order issue",
    body: "Damage during delivery, a missing item, or another order-level problem outside normal wear.",
  },
];

export function BuyerProtectionSection({ compact = false }: { compact?: boolean }) {
  return (
    <div>
      {!compact && (
        <div className="mb-8 flex items-start gap-4">
          <ShieldCheck className="h-8 w-8 shrink-0 text-primary" strokeWidth={1.5} />
          <div>
            <h2 className="text-2xl font-medium tracking-tight">Buyer Protection</h2>
            <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted-foreground">
              Every order placed through XFY Outfit is covered for a defined set of eligible issues. This isn't a
              blanket guarantee — it's a clear, honest scope of what's covered and how to use it.
            </p>
          </div>
        </div>
      )}

      <div className="flex items-center gap-2.5 border border-primary/25 bg-primary/5 px-4 py-3 text-sm">
        <Clock className="h-4 w-4 shrink-0 text-primary" />
        <span>Return requests must be submitted within <strong className="font-medium">7 days after delivery</strong>.</span>
      </div>

      <Accordion className="mt-6">
        {CASES.map((item) => (
          <AccordionItem
            key={item.title}
            title={
              <span className="flex items-center gap-3">
                <item.icon className="h-4 w-4 shrink-0 text-muted-foreground" strokeWidth={1.5} />
                {item.title}
              </span>
            }
          >
            {item.body}
          </AccordionItem>
        ))}
      </Accordion>

      <p className="mt-6 text-xs leading-relaxed text-muted-foreground">
        Buyer Protection covers the cases above when reported within the return window and reviewed by the XFY
        team. It does not cover ordinary wear consistent with an item's stated condition, change of mind, or
        sizing preferences outside recorded measurements.
      </p>
    </div>
  );
}
