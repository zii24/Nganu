import { cn } from "@/lib/utils";

export function Logo({ className }: { className?: string }) {
  return (
    <span className={cn("font-semibold tracking-tight", className)}>
      XFY <span className="font-normal text-muted-foreground">Outfit</span>
    </span>
  );
}
