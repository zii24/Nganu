"use client";

import Link from "next/link";
import Image from "next/image";
import { getActiveCategories, getPublishedProducts } from "@/lib/mock-data";
import { useLanguage } from "@/context/LanguageContext";

export function CategoryGrid() {
  const { t } = useLanguage();
  const categories = getActiveCategories();
  const products = getPublishedProducts();

  if (categories.length === 0) return null;

  return (
    <section className="border-b border-t border-border bg-secondary/40">
      <div className="container py-14 lg:py-20">
        <h2 className="mb-7 text-2xl font-medium tracking-tight sm:text-[28px]">{t("categories")}</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {categories.map((category) => {
            const sample = products.find((p) => p.category === category);
            const count = products.filter((p) => p.category === category).length;
            return (
              <Link
                key={category}
                href={`/shop?category=${encodeURIComponent(category)}`}
                className="group relative aspect-[3/4] overflow-hidden bg-secondary"
              >
                {sample && (
                  <Image
                    src={sample.images[0].url}
                    alt={category}
                    fill
                    sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 16vw"
                    className="object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                  />
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/55 via-black/0 to-black/0" />
                <div className="absolute inset-x-0 bottom-0 p-3">
                  <p className="text-sm font-medium text-white">{category}</p>
                  <p className="text-[11px] text-white/75">{count} item{count !== 1 ? "s" : ""}</p>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}
