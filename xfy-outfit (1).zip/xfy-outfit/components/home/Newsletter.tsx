"use client";

import { useState, FormEvent } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";

export function Newsletter() {
  const { t } = useLanguage();
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!email.trim()) return;
    // Mock only — wire this to an email provider (e.g. Klaviyo/Resend) later.
    setSubmitted(true);
  }

  return (
    <section className="border-t border-border bg-foreground text-background">
      <div className="container flex flex-col items-center gap-5 py-16 text-center lg:py-20">
        <h2 className="max-w-md text-2xl font-medium tracking-tight sm:text-[28px]">{t("newsletter_title")}</h2>
        <p className="max-w-sm text-sm text-background/70">{t("newsletter_sub")}</p>
        {submitted ? (
          <p className="mt-2 flex items-center gap-2 text-sm font-medium text-background">
            <Check className="h-4 w-4" /> You&rsquo;re on the list.
          </p>
        ) : (
          <form onSubmit={handleSubmit} className="mt-2 flex w-full max-w-sm flex-col gap-2.5 sm:flex-row">
            <Input
              type="email"
              required
              placeholder={t("newsletter_placeholder")}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="border-background/25 bg-transparent text-background placeholder:text-background/50 focus-visible:border-background"
            />
            <Button type="submit" variant="dark" className="shrink-0 bg-background text-foreground hover:bg-background/85">
              {t("newsletter_cta")}
            </Button>
          </form>
        )}
      </div>
    </section>
  );
}
