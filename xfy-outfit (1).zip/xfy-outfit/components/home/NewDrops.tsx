"use client";

import { getPublishedProducts } from "@/lib/mock-data";
import { isNewDrop } from "@/lib/utils";
import { ProductGrid } from "@/components/product/ProductGrid";
import { SectionHeading } from "@/components/shared/SectionHeading";
import { useLanguage } from "@/context/LanguageContext";

export function NewDrops() {
  const { t } = useLanguage();
  const products = getPublishedProducts()
    .filter((p) => isNewDrop(p.publishedAt))
    .sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime());

  if (products.length === 0) return null;

  return (
    <section className="container py-14 lg:py-20">
      <SectionHeading title={t("new_drops")} subtitle={t("new_drops_sub")} viewAllHref="/shop?filter=new" viewAllLabel={t("view_all")} />
      <ProductGrid products={products} />
    </section>
  );
}
