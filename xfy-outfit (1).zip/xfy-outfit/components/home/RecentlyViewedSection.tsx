"use client";

import { useRecentlyViewed } from "@/context/RecentlyViewedContext";
import { PRODUCTS } from "@/lib/mock-data";
import { ProductGrid } from "@/components/product/ProductGrid";
import { SectionHeading } from "@/components/shared/SectionHeading";
import { useLanguage } from "@/context/LanguageContext";

export function RecentlyViewedSection({ excludeId }: { excludeId?: string }) {
  const { ids, hydrated } = useRecentlyViewed();
  const { t } = useLanguage();

  if (!hydrated) return null;

  const products = ids
    .filter((id) => id !== excludeId)
    .map((id) => PRODUCTS.find((p) => p.id === id))
    .filter((p): p is NonNullable<typeof p> => Boolean(p));

  if (products.length === 0) return null;

  return (
    <section className="container py-14 lg:py-20">
      <SectionHeading title={t("recently_viewed")} />
      <ProductGrid products={products} />
    </section>
  );
}
