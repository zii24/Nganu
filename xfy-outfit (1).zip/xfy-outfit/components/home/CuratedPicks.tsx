"use client";

import { getPublishedProducts } from "@/lib/mock-data";
import { ProductGrid } from "@/components/product/ProductGrid";
import { SectionHeading } from "@/components/shared/SectionHeading";
import { useLanguage } from "@/context/LanguageContext";

export function CuratedPicks() {
  const { t } = useLanguage();
  const products = getPublishedProducts()
    .filter((p) => p.condition >= 9)
    .slice(0, 8);

  if (products.length === 0) return null;

  return (
    <section className="container py-14 lg:py-20">
      <SectionHeading title={t("curated_picks")} subtitle={t("curated_picks_sub")} viewAllHref="/shop" viewAllLabel={t("view_all")} />
      <ProductGrid products={products} />
    </section>
  );
}
