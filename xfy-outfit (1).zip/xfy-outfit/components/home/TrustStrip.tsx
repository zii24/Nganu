"use client";

import { Sparkles, ShieldCheck, SearchCheck, PackageCheck, Globe } from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";

export function TrustStrip() {
  const { t } = useLanguage();

  const items = [
    { icon: Sparkles, title: t("trust_curated"), sub: t("trust_curated_sub") },
    { icon: SearchCheck, title: t("trust_condition"), sub: t("trust_condition_sub") },
    { icon: PackageCheck, title: t("trust_inspection"), sub: t("trust_inspection_sub") },
    { icon: ShieldCheck, title: t("trust_protection"), sub: t("trust_protection_sub") },
    { icon: Globe, title: t("trust_shipping"), sub: t("trust_shipping_sub") },
  ];

  return (
    <section className="border-b border-border">
      <div className="container grid grid-cols-2 gap-6 py-8 sm:grid-cols-3 lg:grid-cols-5 lg:gap-4 lg:py-7">
        {items.map((item) => (
          <div key={item.title} className="flex items-start gap-3">
            <item.icon className="mt-0.5 h-5 w-5 shrink-0 text-primary" strokeWidth={1.5} />
            <div>
              <p className="text-[13px] font-medium leading-snug">{item.title}</p>
              <p className="mt-0.5 text-xs leading-snug text-muted-foreground">{item.sub}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
