"use client";

import { SearchCheck, Ruler, BadgeCheck, ShieldCheck } from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";

export function WhyShopXFY() {
  const { t } = useLanguage();

  const points = [
    {
      icon: SearchCheck,
      title: "Condition, stated plainly",
      body: "Every listing carries a fixed 1–10 score with notes on any fading, marks, or wear — no guessing from photos alone.",
    },
    {
      icon: Ruler,
      title: "Real measurements, not just sizes",
      body: "Sizing varies by brand and era. We measure key points by hand so you know how a piece actually fits before it ships.",
    },
    {
      icon: BadgeCheck,
      title: "Authenticity, checked",
      body: "Items are marked Original, Not Verified, or Not Original based on our team's inspection — never left to assumption.",
    },
    {
      icon: ShieldCheck,
      title: "Covered if something's off",
      body: "Eligible issues — wrong item, materially different condition, or an authenticity concern — are covered under Buyer Protection.",
    },
  ];

  return (
    <section className="border-t border-border">
      <div className="container py-14 lg:py-20">
        <h2 className="mb-9 text-2xl font-medium tracking-tight sm:text-[28px]">{t("why_xfy")}</h2>
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4 lg:gap-6">
          {points.map((point) => (
            <div key={point.title}>
              <point.icon className="h-6 w-6 text-primary" strokeWidth={1.5} />
              <p className="mt-4 text-[15px] font-medium leading-snug">{point.title}</p>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{point.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
