"use client";

import { Store, Users } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useLanguage } from "@/context/LanguageContext";

export function ComingSoon() {
  const { t } = useLanguage();

  return (
    <section className="container py-14 lg:py-20">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="border border-border p-8">
          <div className="flex items-center justify-between">
            <Store className="h-6 w-6 text-primary" strokeWidth={1.5} />
            <Badge variant="outline">{t("coming_soon")}</Badge>
          </div>
          <p className="mt-5 text-lg font-medium">{t("sell_title")}</p>
          <p className="mt-2 max-w-sm text-sm text-muted-foreground">{t("sell_sub")}</p>
        </div>
        <div className="border border-border p-8">
          <div className="flex items-center justify-between">
            <Users className="h-6 w-6 text-primary" strokeWidth={1.5} />
            <Badge variant="outline">{t("coming_soon")}</Badge>
          </div>
          <p className="mt-5 text-lg font-medium">{t("affiliate_title")}</p>
          <p className="mt-2 max-w-sm text-sm text-muted-foreground">{t("affiliate_sub")}</p>
        </div>
      </div>
    </section>
  );
}
