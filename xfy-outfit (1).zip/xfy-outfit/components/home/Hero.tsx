"use client";

import Image from "next/image";
import Link from "next/link";
import { buttonVariants } from "@/components/ui/button";
import { useLanguage } from "@/context/LanguageContext";

export function Hero() {
  const { t } = useLanguage();

  return (
    <section className="border-b border-border">
      <div className="container grid grid-cols-1 items-stretch gap-8 py-10 lg:grid-cols-2 lg:gap-12 lg:py-0">
        <div className="flex flex-col justify-center py-4 lg:py-24">
          <p className="text-xs font-medium uppercase tracking-[0.14em] text-primary">{t("hero_eyebrow")}</p>
          <h1 className="mt-4 max-w-lg text-4xl font-medium leading-[1.08] tracking-tight text-balance sm:text-5xl lg:text-[52px]">
            {t("hero_title")}
          </h1>
          <p className="mt-5 max-w-md text-[15px] leading-relaxed text-muted-foreground">{t("hero_sub")}</p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Link href="/shop" className={buttonVariants({ size: "lg" })}>
              {t("hero_cta_shop")}
            </Link>
            <Link href="/shop?filter=new" className={buttonVariants({ size: "lg", variant: "outline" })}>
              {t("hero_cta_new")}
            </Link>
          </div>
        </div>
        <div className="relative order-first aspect-[4/3] overflow-hidden bg-secondary lg:order-last lg:aspect-auto">
          <Image
            src="https://picsum.photos/seed/xfy-hero-editorial/1400/1400"
            alt="XFY curated second-hand fashion, editorial photography"
            fill
            priority
            sizes="(max-width: 1024px) 100vw, 50vw"
            className="object-cover"
          />
        </div>
      </div>
    </section>
  );
}
