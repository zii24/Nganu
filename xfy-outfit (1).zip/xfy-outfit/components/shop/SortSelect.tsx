"use client";

import { Select } from "@/components/ui/select";
import { useLanguage } from "@/context/LanguageContext";

export type SortValue = "newest" | "price-low" | "price-high" | "condition";

export function SortSelect({ value, onChange }: { value: SortValue; onChange: (v: SortValue) => void }) {
  const { t } = useLanguage();
  return (
    <Select value={value} onChange={(e) => onChange(e.target.value as SortValue)} className="h-10 w-auto min-w-[180px] text-sm">
      <option value="newest">{t("sort_newest")}</option>
      <option value="price-low">{t("sort_price_low")}</option>
      <option value="price-high">{t("sort_price_high")}</option>
      <option value="condition">{t("sort_condition")}</option>
    </Select>
  );
}
