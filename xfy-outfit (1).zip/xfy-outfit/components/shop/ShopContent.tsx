"use client";

import { useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { SlidersHorizontal } from "lucide-react";
import { getPublishedProducts } from "@/lib/mock-data";
import { formatAmount, isNewDrop } from "@/lib/utils";
import type { Category, ConditionScore } from "@/lib/types";
import { ProductGrid } from "@/components/product/ProductGrid";
import { Filters, type ShopFilterState } from "./Filters";
import { FilterDrawer } from "./FilterDrawer";
import { SortSelect, type SortValue } from "./SortSelect";
import { Button } from "@/components/ui/button";
import { useCurrency } from "@/context/CurrencyContext";
import { useLanguage } from "@/context/LanguageContext";

const EMPTY_FILTERS: ShopFilterState = {
  categories: [],
  conditions: [],
  sizes: [],
  minPrice: "",
  maxPrice: "",
};

export function ShopContent() {
  const params = useSearchParams();
  const { currency } = useCurrency();
  const { t } = useLanguage();

  const initialCategory = params.get("category") as Category | null;
  const newOnly = params.get("filter") === "new";

  const [filters, setFilters] = useState<ShopFilterState>(
    initialCategory ? { ...EMPTY_FILTERS, categories: [initialCategory] } : EMPTY_FILTERS
  );
  const [sort, setSort] = useState<SortValue>("newest");
  const [drawerOpen, setDrawerOpen] = useState(false);

  const allProducts = useMemo(() => getPublishedProducts(), []);

  const availableCategories = useMemo(
    () => Array.from(new Set(allProducts.map((p) => p.category))).sort(),
    [allProducts]
  );
  const availableConditions = useMemo(
    () => Array.from(new Set(allProducts.map((p) => p.condition))) as ConditionScore[],
    [allProducts]
  );
  const availableSizes = useMemo(
    () => Array.from(new Set(allProducts.map((p) => p.size))).sort(),
    [allProducts]
  );

  const filtered = useMemo(() => {
    let list = allProducts;

    if (newOnly) list = list.filter((p) => isNewDrop(p.publishedAt));
    if (filters.categories.length) list = list.filter((p) => filters.categories.includes(p.category));
    if (filters.conditions.length) list = list.filter((p) => filters.conditions.includes(p.condition));
    if (filters.sizes.length) list = list.filter((p) => filters.sizes.includes(p.size));

    const min = filters.minPrice ? Number(filters.minPrice) : undefined;
    const max = filters.maxPrice ? Number(filters.maxPrice) : undefined;
    if (min !== undefined) list = list.filter((p) => (currency === "IDR" ? p.priceIdr : p.priceUsd) >= min);
    if (max !== undefined) list = list.filter((p) => (currency === "IDR" ? p.priceIdr : p.priceUsd) <= max);

    const sorted = [...list];
    switch (sort) {
      case "price-low":
        sorted.sort((a, b) => (currency === "IDR" ? a.priceIdr - b.priceIdr : a.priceUsd - b.priceUsd));
        break;
      case "price-high":
        sorted.sort((a, b) => (currency === "IDR" ? b.priceIdr - a.priceIdr : b.priceUsd - a.priceUsd));
        break;
      case "condition":
        sorted.sort((a, b) => b.condition - a.condition);
        break;
      case "newest":
      default:
        sorted.sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime());
    }
    return sorted;
  }, [allProducts, filters, sort, currency, newOnly]);

  const filterProps = { availableCategories, availableConditions, availableSizes, filters, onChange: setFilters, onClear: () => setFilters(EMPTY_FILTERS) };

  return (
    <div className="container py-8 lg:py-10">
      <div className="mb-7">
        <h1 className="text-2xl font-medium tracking-tight sm:text-[28px]">{newOnly ? t("new_drops") : t("shop_title")}</h1>
        <p className="mt-1.5 text-sm text-muted-foreground">
          Showing {filtered.length} of {allProducts.length} products
          {currency && (filters.minPrice || filters.maxPrice) ? ` · ${formatAmount(Number(filters.minPrice) || 0, currency)}${filters.maxPrice ? ` – ${formatAmount(Number(filters.maxPrice), currency)}` : "+"}` : ""}
        </p>
      </div>

      <div className="flex gap-10">
        <aside className="hidden w-[240px] shrink-0 lg:block">
          <Filters {...filterProps} />
        </aside>

        <div className="min-w-0 flex-1">
          <div className="mb-6 flex items-center justify-between gap-3">
            <Button variant="outline" size="sm" className="lg:hidden" onClick={() => setDrawerOpen(true)}>
              <SlidersHorizontal className="h-3.5 w-3.5" />
              {t("filters")}
            </Button>
            <div className="ml-auto">
              <SortSelect value={sort} onChange={setSort} />
            </div>
          </div>

          <ProductGrid products={filtered} />
        </div>
      </div>

      <FilterDrawer open={drawerOpen} onOpenChange={setDrawerOpen} resultCount={filtered.length} {...filterProps} />
    </div>
  );
}
