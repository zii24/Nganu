"use client";

import type { Category, ConditionScore } from "@/lib/types";
import { CONDITION_LABEL } from "@/lib/types";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useCurrency } from "@/context/CurrencyContext";
import { useLanguage } from "@/context/LanguageContext";

export interface ShopFilterState {
  categories: Category[];
  conditions: ConditionScore[];
  sizes: string[];
  minPrice: string;
  maxPrice: string;
}

export function FilterSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="border-b border-border py-5 first:pt-0">
      <p className="mb-3 text-sm font-medium">{title}</p>
      {children}
    </div>
  );
}

export function Filters({
  availableCategories,
  availableConditions,
  availableSizes,
  filters,
  onChange,
  onClear,
}: {
  availableCategories: Category[];
  availableConditions: ConditionScore[];
  availableSizes: string[];
  filters: ShopFilterState;
  onChange: (next: ShopFilterState) => void;
  onClear: () => void;
}) {
  const { currency } = useCurrency();
  const { t } = useLanguage();

  function toggle<T>(list: T[], value: T): T[] {
    return list.includes(value) ? list.filter((v) => v !== value) : [...list, value];
  }

  const hasActiveFilters =
    filters.categories.length > 0 ||
    filters.conditions.length > 0 ||
    filters.sizes.length > 0 ||
    filters.minPrice !== "" ||
    filters.maxPrice !== "";

  return (
    <div>
      <div className="flex items-center justify-between pb-1">
        <p className="text-sm font-medium">{t("filters")}</p>
        {hasActiveFilters && (
          <button onClick={onClear} className="text-xs text-muted-foreground underline underline-offset-2 hover:text-foreground">
            {t("clear_filters")}
          </button>
        )}
      </div>

      <FilterSection title={t("filter_category")}>
        <div className="space-y-2.5">
          {availableCategories.map((category) => (
            <label key={category} className="flex cursor-pointer items-center gap-2.5 text-sm">
              <Checkbox
                checked={filters.categories.includes(category)}
                onChange={() => onChange({ ...filters, categories: toggle(filters.categories, category) })}
              />
              {category}
            </label>
          ))}
        </div>
      </FilterSection>

      <FilterSection title={t("filter_condition")}>
        <div className="space-y-2.5">
          {availableConditions
            .sort((a, b) => b - a)
            .map((condition) => (
              <label key={condition} className="flex cursor-pointer items-center gap-2.5 text-sm">
                <Checkbox
                  checked={filters.conditions.includes(condition)}
                  onChange={() => onChange({ ...filters, conditions: toggle(filters.conditions, condition) })}
                />
                {condition}/10 &middot; {CONDITION_LABEL[condition]}
              </label>
            ))}
        </div>
      </FilterSection>

      <FilterSection title={t("filter_size")}>
        <div className="flex flex-wrap gap-2">
          {availableSizes.map((size) => {
            const active = filters.sizes.includes(size);
            return (
              <button
                key={size}
                onClick={() => onChange({ ...filters, sizes: toggle(filters.sizes, size) })}
                className={`border px-3 py-1.5 text-xs font-medium rounded-sm ${
                  active ? "border-foreground bg-foreground text-background" : "border-border hover:border-foreground/40"
                }`}
              >
                {size}
              </button>
            );
          })}
        </div>
      </FilterSection>

      <FilterSection title={`${t("filter_price")} (${currency})`}>
        <div className="flex items-center gap-2">
          <Input
            type="number"
            inputMode="numeric"
            placeholder="Min"
            value={filters.minPrice}
            onChange={(e) => onChange({ ...filters, minPrice: e.target.value })}
            className="h-10 text-sm"
          />
          <span className="text-muted-foreground">–</span>
          <Input
            type="number"
            inputMode="numeric"
            placeholder="Max"
            value={filters.maxPrice}
            onChange={(e) => onChange({ ...filters, maxPrice: e.target.value })}
            className="h-10 text-sm"
          />
        </div>
      </FilterSection>
    </div>
  );
}
