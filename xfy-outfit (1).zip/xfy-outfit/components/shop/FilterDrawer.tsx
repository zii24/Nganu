"use client";

import { Sheet } from "@/components/ui/sheet";
import { Filters, type ShopFilterState } from "./Filters";
import { Button } from "@/components/ui/button";
import type { Category, ConditionScore } from "@/lib/types";

export function FilterDrawer({
  open,
  onOpenChange,
  resultCount,
  ...filterProps
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  resultCount: number;
  availableCategories: Category[];
  availableConditions: ConditionScore[];
  availableSizes: string[];
  filters: ShopFilterState;
  onChange: (next: ShopFilterState) => void;
  onClear: () => void;
}) {
  return (
    <Sheet open={open} onOpenChange={onOpenChange} side="bottom" title="Filters" className="max-h-[88vh]">
      <Filters {...filterProps} />
      <div className="sticky bottom-0 -mx-5 -mb-5 mt-6 border-t border-border bg-background p-5">
        <Button className="w-full" onClick={() => onOpenChange(false)}>
          Show {resultCount} item{resultCount !== 1 ? "s" : ""}
        </Button>
      </div>
    </Sheet>
  );
}
