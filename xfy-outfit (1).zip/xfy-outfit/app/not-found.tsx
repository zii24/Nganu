import Link from "next/link";
import { Compass } from "lucide-react";
import { buttonVariants } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="container flex flex-col items-center py-24 text-center">
      <Compass className="h-8 w-8 text-muted-foreground" strokeWidth={1.5} />
      <h1 className="mt-4 text-2xl font-medium tracking-tight">Page not found</h1>
      <p className="mt-2 max-w-sm text-sm text-muted-foreground">
        The page you're looking for doesn't exist or may have been moved.
      </p>
      <Link href="/" className={buttonVariants({ className: "mt-6" })}>
        Back to Home
      </Link>
    </div>
  );
}
