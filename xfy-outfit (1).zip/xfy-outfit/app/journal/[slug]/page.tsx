import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ChevronLeft } from "lucide-react";
import { getArticleBySlug, JOURNAL_ARTICLES } from "@/lib/mock-journal";
import { formatDate } from "@/lib/utils";

export function generateStaticParams() {
  return JOURNAL_ARTICLES.map((a) => ({ slug: a.slug }));
}

export function generateMetadata({ params }: { params: { slug: string } }) {
  const article = getArticleBySlug(params.slug);
  return { title: article ? `${article.title} — XFY Journal` : "Article Not Found" };
}

export default function JournalArticlePage({ params }: { params: { slug: string } }) {
  const article = getArticleBySlug(params.slug);
  if (!article) notFound();

  return (
    <article className="container max-w-2xl py-8 lg:py-10">
      <Link href="/journal" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ChevronLeft className="h-3.5 w-3.5" /> Journal
      </Link>

      <p className="mt-6 text-xs font-medium uppercase tracking-wide text-primary">{article.category}</p>
      <h1 className="mt-2 text-3xl font-medium tracking-tight text-balance">{article.title}</h1>
      <p className="mt-3 text-sm text-muted-foreground">{formatDate(article.publishedAt)}</p>

      <div className="relative mt-8 aspect-[3/2] overflow-hidden bg-secondary">
        <Image src={article.cover} alt={article.title} fill sizes="700px" className="object-cover" priority />
      </div>

      <div className="mt-8 space-y-5">
        {article.body.map((paragraph, i) => (
          <p key={i} className="text-[15px] leading-relaxed text-muted-foreground">
            {paragraph}
          </p>
        ))}
      </div>
    </article>
  );
}
