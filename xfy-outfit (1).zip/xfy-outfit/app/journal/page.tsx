import Link from "next/link";
import Image from "next/image";
import { JOURNAL_ARTICLES } from "@/lib/mock-journal";
import { formatDate } from "@/lib/utils";

export const metadata = { title: "Journal — XFY Outfit" };

export default function JournalPage() {
  const [featured, ...rest] = JOURNAL_ARTICLES;

  return (
    <div className="container py-8 lg:py-10">
      <div className="mb-9 max-w-lg">
        <h1 className="text-2xl font-medium tracking-tight sm:text-[28px]">XFY Journal</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Stories, interviews, and fashion insight from Indonesia and beyond — plus a look inside how we source and
          inspect.
        </p>
      </div>

      {featured && (
        <Link href={`/journal/${featured.slug}`} className="group mb-12 grid grid-cols-1 gap-6 lg:grid-cols-2 lg:gap-10">
          <div className="relative aspect-[3/2] overflow-hidden bg-secondary">
            <Image
              src={featured.cover}
              alt={featured.title}
              fill
              sizes="(max-width: 1024px) 100vw, 50vw"
              className="object-cover transition-transform duration-300 group-hover:scale-[1.02]"
            />
          </div>
          <div className="flex flex-col justify-center">
            <p className="text-xs font-medium uppercase tracking-wide text-primary">{featured.category}</p>
            <h2 className="mt-2 text-2xl font-medium tracking-tight">{featured.title}</h2>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{featured.excerpt}</p>
            <p className="mt-4 text-xs text-muted-foreground">{formatDate(featured.publishedAt)}</p>
          </div>
        </Link>
      )}

      <div className="grid grid-cols-1 gap-8 border-t border-border pt-10 sm:grid-cols-2 lg:grid-cols-3">
        {rest.map((article) => (
          <Link key={article.slug} href={`/journal/${article.slug}`} className="group">
            <div className="relative aspect-[3/2] overflow-hidden bg-secondary">
              <Image
                src={article.cover}
                alt={article.title}
                fill
                sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                className="object-cover transition-transform duration-300 group-hover:scale-[1.02]"
              />
            </div>
            <p className="mt-3 text-xs font-medium uppercase tracking-wide text-primary">{article.category}</p>
            <p className="mt-1 text-[15px] font-medium leading-snug">{article.title}</p>
            <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground line-clamp-2">{article.excerpt}</p>
            <p className="mt-2 text-xs text-muted-foreground">{formatDate(article.publishedAt)}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
