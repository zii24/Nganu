import Image from "next/image";
import Link from "next/link";
import { Store, Users, Clock } from "lucide-react";
import { BuyerProtectionSection } from "@/components/shared/BuyerProtectionSection";
import { getEnabledRegions } from "@/lib/mock-shipping";
import { formatAmount } from "@/lib/utils";
import { Table, THead, TBody, TR, TH, TD } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

export const metadata = { title: "About — XFY Outfit" };

export default function AboutPage() {
  const regions = getEnabledRegions();

  return (
    <div>
      <section className="border-b border-border">
        <div className="container grid grid-cols-1 gap-8 py-12 lg:grid-cols-2 lg:gap-14 lg:py-20">
          <div className="flex flex-col justify-center">
            <p className="text-xs font-medium uppercase tracking-[0.14em] text-primary">About XFY Outfit</p>
            <h1 className="mt-4 max-w-md text-3xl font-medium leading-tight tracking-tight sm:text-4xl">
              We built the marketplace we wished existed for second-hand fashion.
            </h1>
            <p className="mt-5 max-w-md text-[15px] leading-relaxed text-muted-foreground">
              XFY Outfit is a curated platform for pre-owned fashion in Indonesia. Every piece is inspected,
              measured, and graded by our team before it's listed — condition and authenticity stated plainly, not
              implied by good photography.
            </p>
            <p className="mt-4 max-w-md text-[15px] leading-relaxed text-muted-foreground">
              We started XFY because buying second-hand shouldn't mean guessing. And selling shouldn't mean
              undervaluing pieces that deserve better than a bulk thrift bin.
            </p>
          </div>
          <div className="relative aspect-[4/3] overflow-hidden bg-secondary">
            <Image
              src="https://picsum.photos/seed/xfy-about-team/1200/900"
              alt="XFY Outfit inspection team at work"
              fill
              sizes="(max-width: 1024px) 100vw, 50vw"
              className="object-cover"
            />
          </div>
        </div>
      </section>

      <section id="buyer-protection" className="scroll-mt-24 border-b border-border">
        <div className="container py-14 lg:py-20">
          <BuyerProtectionSection />
        </div>
      </section>

      <section id="shipping" className="scroll-mt-24 border-b border-border">
        <div className="container py-14 lg:py-20">
          <h2 className="text-2xl font-medium tracking-tight">Shipping</h2>
          <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted-foreground">
            All orders ship from Indonesia. Rates and delivery windows below are configurable estimates — not
            guaranteed courier commitments — and may be updated by the XFY team.
          </p>
          <div className="mt-6 border border-border">
            <Table>
              <THead>
                <TR>
                  <TH>Region</TH>
                  <TH>Fee (IDR)</TH>
                  <TH>Fee (USD)</TH>
                  <TH>Estimated Delivery</TH>
                </TR>
              </THead>
              <TBody>
                {regions.map((r) => (
                  <TR key={r.id}>
                    <TD className="font-medium">{r.name}</TD>
                    <TD className="text-muted-foreground">{formatAmount(r.feeIdr, "IDR")}</TD>
                    <TD className="text-muted-foreground">{formatAmount(r.feeUsd, "USD")}</TD>
                    <TD className="text-muted-foreground">
                      {r.minDays}–{r.maxDays} business days
                    </TD>
                  </TR>
                ))}
              </TBody>
            </Table>
          </div>
        </div>
      </section>

      <section id="returns" className="scroll-mt-24 border-b border-border">
        <div className="container py-14 lg:py-20">
          <h2 className="text-2xl font-medium tracking-tight">Returns</h2>
          <div className="mt-4 flex items-center gap-2.5 border border-primary/25 bg-primary/5 px-4 py-3 text-sm">
            <Clock className="h-4 w-4 shrink-0 text-primary" />
            Return requests must be submitted within 7 days after delivery.
          </div>
          <p className="mt-4 max-w-xl text-sm leading-relaxed text-muted-foreground">
            Eligible returns are reviewed under XFY's Buyer Protection policy above. To start a return, open your
            order under <Link href="/order" className="text-primary hover:underline">Order Tracking</Link> and use
            the Request a Return option — you'll be connected with XFY Support on WhatsApp to complete the process.
          </p>
        </div>
      </section>

      <section id="sell" className="scroll-mt-24">
        <div className="container py-14 lg:py-20">
          <h2 className="mb-7 text-2xl font-medium tracking-tight">What's Next for XFY</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="border border-border p-8">
              <div className="flex items-center justify-between">
                <Store className="h-6 w-6 text-primary" strokeWidth={1.5} />
                <Badge variant="outline">Coming Soon</Badge>
              </div>
              <p className="mt-5 text-lg font-medium">Sell With XFY</p>
              <p className="mt-2 max-w-sm text-sm text-muted-foreground">
                Submit your own pieces for curation, inspection, and a listing on XFY. We're building the seller
                intake flow now.
              </p>
            </div>
            <div className="border border-border p-8">
              <div className="flex items-center justify-between">
                <Users className="h-6 w-6 text-primary" strokeWidth={1.5} />
                <Badge variant="outline">Coming Soon</Badge>
              </div>
              <p className="mt-5 text-lg font-medium">Affiliate Program</p>
              <p className="mt-2 max-w-sm text-sm text-muted-foreground">
                Earn from every piece you help place. Affiliate tracking and payouts are in development.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
