import { Hero } from "@/components/home/Hero";
import { TrustStrip } from "@/components/home/TrustStrip";
import { NewDrops } from "@/components/home/NewDrops";
import { CategoryGrid } from "@/components/home/CategoryGrid";
import { CuratedPicks } from "@/components/home/CuratedPicks";
import { RecentlyViewedSection } from "@/components/home/RecentlyViewedSection";
import { WhyShopXFY } from "@/components/home/WhyShopXFY";
import { Newsletter } from "@/components/home/Newsletter";
import { ComingSoon } from "@/components/home/ComingSoon";

export default function HomePage() {
  return (
    <>
      <Hero />
      <TrustStrip />
      <NewDrops />
      <CategoryGrid />
      <CuratedPicks />
      <RecentlyViewedSection />
      <WhyShopXFY />
      <Newsletter />
      <ComingSoon />
    </>
  );
}
