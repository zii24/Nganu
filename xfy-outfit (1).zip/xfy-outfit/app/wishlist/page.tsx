"use client";

import Link from "next/link";
import { Heart } from "lucide-react";
import { useWishlist } from "@/context/WishlistContext";
import { PRODUCTS } from "@/lib/mock-data";
import { ProductGrid } from "@/components/product/ProductGrid";
import { EmptyState } from "@/components/shared/EmptyState";
import { Skeleton } from "@/components/ui/skeleton";
import { buttonVariants } from "@/components/ui/button";
import { useLanguage } from "@/context/LanguageContext";

export default function WishlistPage() {
  const { ids, hydrated } = useWishlist();
  const { t } = useLanguage();

  const products = ids
    .map((id) => PRODUCTS.find((p) => p.id === id))
    .filter((p): p is NonNullable<typeof p> => Boolean(p) && p!.inventoryStatus !== "Draft" && p!.inventoryStatus !== "Archived");

  return (
    <div className="container py-8 lg:py-10">
      <h1 className="mb-7 text-2xl font-medium tracking-tight sm:text-[28px]">{t("wishlist")}</h1>

      {!hydrated ? (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="aspect-[4/5] w-full" />
          ))}
        </div>
      ) : products.length === 0 ? (
        <EmptyState
          icon={Heart}
          title={t("empty_wishlist_title")}
          description={t("empty_wishlist_sub")}
          action={
            <Link href="/shop" className={buttonVariants({})}>
              {t("continue_shopping")}
            </Link>
          }
        />
      ) : (
        <ProductGrid products={products} />
      )}
    </div>
  );
}
