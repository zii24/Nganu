"use client";

import Link from "next/link";
import { ShoppingBag } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { PRODUCTS } from "@/lib/mock-data";
import { CartItem } from "@/components/cart/CartItem";
import { EmptyState } from "@/components/shared/EmptyState";
import { Skeleton } from "@/components/ui/skeleton";
import { buttonVariants } from "@/components/ui/button";
import { useCurrency } from "@/context/CurrencyContext";
import { useLanguage } from "@/context/LanguageContext";
import { formatAmount, isPurchasable, cn } from "@/lib/utils";
import { getRegionById } from "@/lib/mock-shipping";

export default function CartPage() {
  const { ids, hydrated } = useCart();
  const { currency } = useCurrency();
  const { t } = useLanguage();

  const items = ids.map((id) => PRODUCTS.find((p) => p.id === id)).filter((p): p is NonNullable<typeof p> => Boolean(p));
  const unavailable = items.filter((p) => !isPurchasable(p.inventoryStatus));
  const purchasableItems = items.filter((p) => isPurchasable(p.inventoryStatus));

  const subtotal = purchasableItems.reduce((sum, p) => sum + (currency === "IDR" ? p.priceIdr : p.priceUsd), 0);
  const defaultRegion = getRegionById("id")!;
  const shipping = purchasableItems.length > 0 ? (currency === "IDR" ? defaultRegion.feeIdr : defaultRegion.feeUsd) : 0;
  const total = subtotal + shipping;

  return (
    <div className="container py-8 lg:py-10">
      <h1 className="mb-7 text-2xl font-medium tracking-tight sm:text-[28px]">{t("cart")}</h1>

      {!hydrated ? (
        <div className="space-y-4">
          {Array.from({ length: 2 }).map((_, i) => (
            <Skeleton key={i} className="h-32 w-full" />
          ))}
        </div>
      ) : items.length === 0 ? (
        <EmptyState
          icon={ShoppingBag}
          title={t("empty_cart_title")}
          description={t("empty_cart_sub")}
          action={
            <Link href="/shop" className={buttonVariants({})}>
              {t("continue_shopping")}
            </Link>
          }
        />
      ) : (
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-[1fr_360px]">
          <div>
            {unavailable.length > 0 && (
              <div className="mb-5 border border-destructive/30 bg-destructive/5 px-4 py-3 text-sm text-destructive">
                {unavailable.length} item{unavailable.length > 1 ? "s" : ""} in your cart{" "}
                {unavailable.length > 1 ? "are" : "is"} no longer available and won&rsquo;t be included in checkout.
              </div>
            )}
            {items.map((product) => (
              <div key={product.id} className={cn(!isPurchasable(product.inventoryStatus) && "opacity-50")}>
                <CartItem product={product} />
              </div>
            ))}
          </div>

          <div className="h-fit border border-border p-6">
            <p className="text-sm font-medium">Order Summary</p>
            <div className="mt-4 space-y-2.5 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">{t("subtotal")}</span>
                <span>{formatAmount(subtotal, currency)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Shipping (est., Indonesia)</span>
                <span>{formatAmount(shipping, currency)}</span>
              </div>
            </div>
            <div className="mt-4 flex justify-between border-t border-border pt-4 text-sm font-medium">
              <span>{t("total")}</span>
              <span>{formatAmount(total, currency)}</span>
            </div>
            <p className="mt-3 text-xs text-muted-foreground">
              Final shipping is calculated at checkout based on your destination.
            </p>
            <Link
              href="/checkout"
              className={cn(
                buttonVariants({ size: "lg" }),
                "mt-5 w-full",
                purchasableItems.length === 0 && "pointer-events-none opacity-40"
              )}
            >
              {t("proceed_to_checkout")}
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
