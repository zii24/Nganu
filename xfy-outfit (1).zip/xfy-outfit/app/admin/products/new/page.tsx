import { ProductForm } from "@/components/admin/ProductForm";

export const metadata = { title: "Add Product — XFY Admin" };

export default function NewProductPage() {
  return (
    <div>
      <h1 className="mb-1 text-xl font-medium tracking-tight">Add Product</h1>
      <p className="mb-7 text-sm text-muted-foreground">Fields marked required must be filled before saving.</p>
      <ProductForm />
    </div>
  );
}
