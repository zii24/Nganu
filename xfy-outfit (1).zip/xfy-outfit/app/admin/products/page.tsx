"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { PlusCircle } from "lucide-react";
import { PRODUCTS } from "@/lib/mock-data";
import { getDraftProducts } from "@/lib/admin-draft-store";
import { CONDITION_LABEL } from "@/lib/types";
import type { Product } from "@/lib/types";
import { StatusBadge } from "@/components/admin/StatusBadge";
import { Table, THead, TBody, TR, TH, TD } from "@/components/ui/table";
import { formatAmount, formatDate } from "@/lib/utils";
import { buttonVariants } from "@/components/ui/button";

export default function AdminProductsPage() {
  const [drafts, setDrafts] = useState<Product[]>([]);

  useEffect(() => {
    setDrafts(getDraftProducts());
  }, []);

  const products = [...drafts, ...PRODUCTS].sort(
    (a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime()
  );

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-xl font-medium tracking-tight">Products</h1>
          <p className="mt-1 text-sm text-muted-foreground">{products.length} total</p>
        </div>
        <Link href="/admin/products/new" className={buttonVariants({ size: "sm" })}>
          <PlusCircle className="h-4 w-4" />
          Add Product
        </Link>
      </div>

      <div className="border border-border bg-background">
        <Table>
          <THead>
            <TR>
              <TH className="pl-5">Product</TH>
              <TH>Category</TH>
              <TH>Price</TH>
              <TH>Condition</TH>
              <TH>Status</TH>
              <TH className="pr-5">Published</TH>
            </TR>
          </THead>
          <TBody>
            {products.map((product) => {
              const front = product.images.find((i) => i.kind === "front") ?? product.images[0];
              return (
                <TR key={product.id}>
                  <TD className="pl-5">
                    <div className="flex items-center gap-3">
                      <div className="relative h-12 w-10 shrink-0 overflow-hidden bg-secondary">
                        {front && <Image src={front.url} alt={front.alt} fill sizes="40px" className="object-cover" />}
                      </div>
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium">{product.name}</p>
                        <p className="text-xs text-muted-foreground">{product.brand}</p>
                      </div>
                    </div>
                  </TD>
                  <TD className="text-muted-foreground">{product.category}</TD>
                  <TD className="text-muted-foreground">{formatAmount(product.priceIdr, "IDR")}</TD>
                  <TD className="text-muted-foreground">
                    {product.condition}/10 · {CONDITION_LABEL[product.condition]}
                  </TD>
                  <TD>
                    <StatusBadge status={product.inventoryStatus} />
                  </TD>
                  <TD className="pr-5 text-muted-foreground">{formatDate(product.publishedAt)}</TD>
                </TR>
              );
            })}
          </TBody>
        </Table>
      </div>
    </div>
  );
}
