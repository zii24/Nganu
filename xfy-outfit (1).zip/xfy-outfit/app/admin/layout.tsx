import type { Metadata } from "next";
import { AdminSidebar } from "@/components/admin/Sidebar";
import { AdminMobileNav } from "@/components/admin/AdminMobileNav";

export const metadata: Metadata = {
  title: "Admin — XFY Outfit",
};

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-secondary/40">
      <AdminSidebar />
      <AdminMobileNav />
      <div className="lg:pl-60">
        <div className="mx-auto max-w-7xl px-5 py-6 sm:px-8 sm:py-8">{children}</div>
      </div>
    </div>
  );
}
