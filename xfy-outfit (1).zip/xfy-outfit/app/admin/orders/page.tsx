"use client";

import { useEffect, useState, Fragment } from "react";
import Link from "next/link";
import { ChevronDown } from "lucide-react";
import { ORDERS } from "@/lib/mock-orders";
import { getAllStoredOrders } from "@/lib/order-store";
import type { Order } from "@/lib/types";
import { StatusBadge } from "@/components/admin/StatusBadge";
import { Table, THead, TBody, TR, TH, TD } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { formatAmount, formatDate, cn } from "@/lib/utils";

export default function AdminOrdersPage() {
  const [stored, setStored] = useState<Order[]>([]);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [notesDraft, setNotesDraft] = useState<Record<string, string>>({});

  useEffect(() => {
    setStored(getAllStoredOrders());
  }, []);

  const orders = [...ORDERS, ...stored.filter((o) => !ORDERS.some((m) => m.id === o.id))].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  return (
    <div>
      <h1 className="mb-1 text-xl font-medium tracking-tight">Orders</h1>
      <p className="mb-6 text-sm text-muted-foreground">{orders.length} total</p>

      <div className="border border-border bg-background">
        <Table>
          <THead>
            <TR>
              <TH className="pl-5">Order ID</TH>
              <TH>Item(s)</TH>
              <TH>Status</TH>
              <TH>Total (IDR)</TH>
              <TH>Date</TH>
              <TH className="pr-5" />
            </TR>
          </THead>
          <TBody>
            {orders.map((order) => (
              <Fragment key={order.id}>
                <TR>
                  <TD className="pl-5 font-medium">
                    <Link href={`/order/${order.id}`} className="hover:underline">
                      {order.id}
                    </Link>
                  </TD>
                  <TD className="text-muted-foreground">
                    {order.items[0]?.name}
                    {order.items.length > 1 ? ` +${order.items.length - 1}` : ""}
                  </TD>
                  <TD>
                    <StatusBadge status={order.status} />
                  </TD>
                  <TD className="text-muted-foreground">{formatAmount(order.totalIdr, "IDR")}</TD>
                  <TD className="text-muted-foreground">{formatDate(order.createdAt)}</TD>
                  <TD className="pr-5">
                    <button
                      onClick={() => setExpanded(expanded === order.id ? null : order.id)}
                      className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
                    >
                      Notes
                      <ChevronDown className={cn("h-3.5 w-3.5 transition-transform", expanded === order.id && "rotate-180")} />
                    </button>
                  </TD>
                </TR>
                {expanded === order.id && (
                  <TR>
                    <TD colSpan={6} className="bg-secondary/40 pl-5">
                      <div className="max-w-lg py-2">
                        <p className="mb-2 text-xs font-medium text-muted-foreground">Inspection notes</p>
                        <Textarea
                          rows={3}
                          defaultValue={order.inspectionNotes ?? ""}
                          onChange={(e) => setNotesDraft((prev) => ({ ...prev, [order.id]: e.target.value }))}
                        />
                        <Button size="sm" variant="outline" className="mt-2">
                          Save Note (demo only)
                        </Button>
                      </div>
                    </TD>
                  </TR>
                )}
              </Fragment>
            ))}
          </TBody>
        </Table>
      </div>
    </div>
  );
}
