import Link from "next/link";
import { Package, CheckCircle2, Clock, ShoppingBag, ListChecks, Percent } from "lucide-react";
import { PRODUCTS } from "@/lib/mock-data";
import { ORDERS } from "@/lib/mock-orders";
import { OFFERS } from "@/lib/mock-offers";
import { StatCard } from "@/components/admin/StatCard";
import { StatusBadge } from "@/components/admin/StatusBadge";
import { Table, THead, TBody, TR, TH, TD } from "@/components/ui/table";
import { formatAmount, formatDate } from "@/lib/utils";

export default function AdminDashboardPage() {
  const total = PRODUCTS.length;
  const available = PRODUCTS.filter((p) => p.inventoryStatus === "Published").length;
  const reserved = PRODUCTS.filter((p) => p.inventoryStatus === "Reserved").length;
  const sold = PRODUCTS.filter((p) => p.inventoryStatus === "Sold").length;

  const recentOrders = [...ORDERS].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, 5);

  return (
    <div>
      <div className="mb-7 flex items-center justify-between">
        <h1 className="text-xl font-medium tracking-tight">Dashboard</h1>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-3 xl:grid-cols-6">
        <StatCard label="Total Products" value={total} icon={Package} />
        <StatCard label="Available" value={available} icon={CheckCircle2} />
        <StatCard label="Reserved" value={reserved} icon={Clock} />
        <StatCard label="Sold" value={sold} icon={ShoppingBag} />
        <StatCard label="Orders" value={ORDERS.length} icon={ListChecks} />
        <StatCard label="Offers" value={OFFERS.length} icon={Percent} />
      </div>

      <div className="mt-8 border border-border bg-background">
        <div className="flex items-center justify-between border-b border-border px-5 py-4">
          <p className="text-sm font-medium">Recent Orders</p>
          <Link href="/admin/orders" className="text-xs text-primary hover:underline">
            View all
          </Link>
        </div>
        <Table>
          <THead>
            <TR>
              <TH className="pl-5">Order ID</TH>
              <TH>Item</TH>
              <TH>Status</TH>
              <TH>Total</TH>
              <TH className="pr-5">Date</TH>
            </TR>
          </THead>
          <TBody>
            {recentOrders.map((order) => (
              <TR key={order.id}>
                <TD className="pl-5 font-medium">
                  <Link href={`/order/${order.id}`} className="hover:underline">
                    {order.id}
                  </Link>
                </TD>
                <TD className="text-muted-foreground">{order.items[0]?.name}{order.items.length > 1 ? ` +${order.items.length - 1}` : ""}</TD>
                <TD>
                  <StatusBadge status={order.status} />
                </TD>
                <TD className="text-muted-foreground">{formatAmount(order.totalIdr, "IDR")}</TD>
                <TD className="pr-5 text-muted-foreground">{formatDate(order.createdAt)}</TD>
              </TR>
            ))}
          </TBody>
        </Table>
      </div>
    </div>
  );
}
