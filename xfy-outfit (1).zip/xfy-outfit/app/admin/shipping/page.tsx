"use client";

import { useState } from "react";
import { Save } from "lucide-react";
import { SHIPPING_REGIONS } from "@/lib/mock-shipping";
import type { ShippingRegion } from "@/lib/types";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Table, THead, TBody, TR, TH, TD } from "@/components/ui/table";
import { cn } from "@/lib/utils";

export default function AdminShippingPage() {
  const [regions, setRegions] = useState<ShippingRegion[]>(SHIPPING_REGIONS);
  const [savedAt, setSavedAt] = useState<number | null>(null);

  function update(id: string, patch: Partial<ShippingRegion>) {
    setRegions((prev) => prev.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  }

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-xl font-medium tracking-tight">Shipping Settings</h1>
          <p className="mt-1 text-sm text-muted-foreground">Configurable estimates shown to buyers — not guaranteed courier rates.</p>
        </div>
        <Button
          size="sm"
          onClick={() => setSavedAt(Date.now())}
        >
          <Save className="h-3.5 w-3.5" />
          Save Changes
        </Button>
      </div>

      {savedAt && (
        <div className="mb-5 border border-success/30 bg-success/5 px-4 py-2.5 text-sm text-success">
          Changes saved for this session (demo only — not yet persisted to a backend).
        </div>
      )}

      <div className="border border-border bg-background">
        <Table>
          <THead>
            <TR>
              <TH className="pl-5">Region</TH>
              <TH>Enabled</TH>
              <TH>Fee (IDR)</TH>
              <TH>Fee (USD)</TH>
              <TH>Min Days</TH>
              <TH className="pr-5">Max Days</TH>
            </TR>
          </THead>
          <TBody>
            {regions.map((region) => (
              <TR key={region.id} className={cn(!region.enabled && "opacity-50")}>
                <TD className="pl-5 font-medium">{region.name}</TD>
                <TD>
                  <button
                    role="switch"
                    aria-checked={region.enabled}
                    onClick={() => update(region.id, { enabled: !region.enabled })}
                    className={cn(
                      "relative h-5 w-9 rounded-full transition-colors",
                      region.enabled ? "bg-primary" : "bg-border"
                    )}
                  >
                    <span
                      className={cn(
                        "absolute top-0.5 h-4 w-4 rounded-full bg-background transition-transform",
                        region.enabled ? "translate-x-[18px]" : "translate-x-0.5"
                      )}
                    />
                  </button>
                </TD>
                <TD>
                  <Input
                    type="number"
                    value={region.feeIdr}
                    onChange={(e) => update(region.id, { feeIdr: Number(e.target.value) })}
                    className="h-9 w-28 text-sm"
                  />
                </TD>
                <TD>
                  <Input
                    type="number"
                    value={region.feeUsd}
                    onChange={(e) => update(region.id, { feeUsd: Number(e.target.value) })}
                    className="h-9 w-20 text-sm"
                  />
                </TD>
                <TD>
                  <Input
                    type="number"
                    value={region.minDays}
                    onChange={(e) => update(region.id, { minDays: Number(e.target.value) })}
                    className="h-9 w-16 text-sm"
                  />
                </TD>
                <TD className="pr-5">
                  <Input
                    type="number"
                    value={region.maxDays}
                    onChange={(e) => update(region.id, { maxDays: Number(e.target.value) })}
                    className="h-9 w-16 text-sm"
                  />
                </TD>
              </TR>
            ))}
          </TBody>
        </Table>
      </div>
    </div>
  );
}
