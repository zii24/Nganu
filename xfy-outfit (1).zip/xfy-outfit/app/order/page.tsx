"use client";

import { useState, FormEvent } from "react";
import { useRouter } from "next/navigation";
import { PackageSearch } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";

export default function OrderLookupPage() {
  const [orderId, setOrderId] = useState("");
  const router = useRouter();

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!orderId.trim()) return;
    router.push(`/order/${orderId.trim()}`);
  }

  return (
    <div className="container flex flex-col items-center py-20 text-center">
      <PackageSearch className="h-8 w-8 text-primary" strokeWidth={1.5} />
      <h1 className="mt-4 text-2xl font-medium tracking-tight">Track Your Order</h1>
      <p className="mt-2 max-w-sm text-sm text-muted-foreground">
        Enter the order ID from your confirmation to see live tracking, inspection status, and delivery estimates.
      </p>
      <form onSubmit={handleSubmit} className="mt-7 w-full max-w-xs">
        <Label htmlFor="orderId" className="sr-only">
          Order ID
        </Label>
        <Input id="orderId" value={orderId} onChange={(e) => setOrderId(e.target.value)} placeholder="e.g. XFY-20260918-0142" />
        <Button type="submit" className="mt-3 w-full">
          Track Order
        </Button>
      </form>
      <p className="mt-4 text-xs text-muted-foreground">Try a demo order: XFY-20260918-0142</p>
    </div>
  );
}
