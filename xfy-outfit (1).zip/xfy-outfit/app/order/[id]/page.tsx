"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { PackageSearch, TriangleAlert, RotateCcw } from "lucide-react";
import { getOrderById } from "@/lib/mock-orders";
import { getStoredOrder, saveOrder } from "@/lib/order-store";
import type { Order } from "@/lib/types";
import { formatAmount, formatDate } from "@/lib/utils";
import { getRegionById } from "@/lib/mock-shipping";
import { Timeline } from "@/components/order/Timeline";
import { ReviewForm } from "@/components/order/ReviewForm";
import { ReturnRequestModal } from "@/components/order/ReturnRequestModal";
import { EmptyState } from "@/components/shared/EmptyState";
import { Button, buttonVariants } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

const RETURN_WINDOW_DAYS = 7;

export default function OrderTrackingPage({ params }: { params: { id: string } }) {
  const [order, setOrder] = useState<Order | null | undefined>(undefined);
  const [returnOpen, setReturnOpen] = useState(false);

  useEffect(() => {
    const found = getOrderById(params.id) ?? getStoredOrder(params.id) ?? null;
    setOrder(found);
  }, [params.id]);

  if (order === undefined) {
    return (
      <div className="container py-10">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="mt-6 h-64 w-full" />
      </div>
    );
  }

  if (order === null) {
    return (
      <div className="container py-16">
        <EmptyState
          icon={PackageSearch}
          title="Order not found"
          description="We couldn't find an order with that ID. Double-check the link, or contact support."
          action={
            <Link href="/shop" className={buttonVariants({})}>
              Continue Shopping
            </Link>
          }
        />
      </div>
    );
  }

  const region = getRegionById(order.shippingRegionId);
  const canReview = (order.status === "Delivered" || order.status === "Completed") && !order.review;
  const daysSinceDelivery = order.deliveredAt
    ? (Date.now() - new Date(order.deliveredAt).getTime()) / (1000 * 60 * 60 * 24)
    : undefined;
  const canReturn =
    (order.status === "Delivered" || order.status === "Completed") &&
    !order.returnRequest &&
    (daysSinceDelivery === undefined || daysSinceDelivery <= RETURN_WINDOW_DAYS);

  function persist(next: Order) {
    setOrder(next);
    saveOrder(next); // no-op-safe even for originally-mock orders; keeps demo state consistent on revisit
  }

  return (
    <div className="container py-8 lg:py-10">
      <div className="mb-7 flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-xs text-muted-foreground">Order</p>
          <h1 className="text-xl font-medium tracking-tight sm:text-2xl">{order.id}</h1>
        </div>
        <p className="text-sm text-muted-foreground">Placed {formatDate(order.createdAt)}</p>
      </div>

      <div className="grid grid-cols-1 gap-10 lg:grid-cols-[1fr_360px]">
        <div>
          {order.status === "Inspection Issue" && order.inspectionNotes && (
            <div className="mb-6 flex gap-3 border border-destructive/30 bg-destructive/5 p-4">
              <TriangleAlert className="mt-0.5 h-5 w-5 shrink-0 text-destructive" strokeWidth={1.5} />
              <div>
                <p className="text-sm font-medium text-destructive">Inspection Issue</p>
                <p className="mt-1 text-sm text-muted-foreground">{order.inspectionNotes}</p>
              </div>
            </div>
          )}

          <h2 className="mb-5 text-lg font-medium">Tracking</h2>
          <Timeline timeline={order.timeline} currentStatus={order.status} />

          {canReview && (
            <div className="mt-10">
              <h2 className="mb-3 text-lg font-medium">Leave a Review</h2>
              <ReviewForm onSubmit={(rating, comment) => persist({ ...order, review: { rating, comment } })} />
            </div>
          )}

          {order.review && (
            <div className="mt-10 border border-border p-5">
              <p className="text-sm font-medium">Your review</p>
              <p className="mt-2 text-sm text-muted-foreground">{"★".repeat(order.review.rating)}{"☆".repeat(5 - order.review.rating)}</p>
              {order.review.comment && <p className="mt-2 text-sm text-muted-foreground">{order.review.comment}</p>}
            </div>
          )}

          {(canReturn || order.returnRequest) && (
            <div className="mt-10">
              <h2 className="mb-3 text-lg font-medium">Return</h2>
              {order.returnRequest ? (
                <div className="border border-border p-4 text-sm text-muted-foreground">
                  Return requested on {formatDate(order.returnRequest.submittedAt)} — reason: {order.returnRequest.reason}.
                  Our team will follow up on WhatsApp.
                </div>
              ) : (
                <Button variant="outline" onClick={() => setReturnOpen(true)}>
                  <RotateCcw className="h-4 w-4" strokeWidth={1.5} />
                  Request a Return
                </Button>
              )}
            </div>
          )}
        </div>

        <div className="space-y-5">
          <div className="border border-border p-5">
            <p className="mb-4 text-sm font-medium">Items</p>
            <div className="space-y-4">
              {order.items.map((item) => (
                <div key={item.productId} className="flex gap-3">
                  <div className="relative h-16 w-[52px] shrink-0 overflow-hidden bg-secondary">
                    <Image src={item.image} alt={item.name} fill sizes="52px" className="object-cover" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <Link href={`/product/${item.slug}`} className="truncate text-sm font-medium hover:underline">
                      {item.name}
                    </Link>
                    <p className="text-xs text-muted-foreground">Size {item.size} · Qty 1</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4 space-y-2 border-t border-border pt-4 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Shipping{region ? ` — ${region.name}` : ""}</span>
                <span>{formatAmount(order.shippingFeeIdr, "IDR")}</span>
              </div>
              <div className="flex justify-between font-medium">
                <span>Total</span>
                <span>{formatAmount(order.totalIdr, "IDR")}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <ReturnRequestModal
        open={returnOpen}
        onOpenChange={setReturnOpen}
        orderId={order.id}
        onSubmitted={(reason) => persist({ ...order, returnRequest: { reason, submittedAt: new Date().toISOString() } })}
      />
    </div>
  );
}
