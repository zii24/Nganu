import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { getProductBySlug, PRODUCTS } from "@/lib/mock-data";
import { ProductDetailContent } from "@/components/product/ProductDetailContent";

export function generateStaticParams() {
  return PRODUCTS.map((p) => ({ slug: p.slug }));
}

export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const product = getProductBySlug(params.slug);
  if (!product) return { title: "Product Not Found — XFY Outfit" };
  return {
    title: `${product.name} — ${product.brand} | XFY Outfit`,
    description: product.descriptionEn,
  };
}

export default function ProductPage({ params }: { params: { slug: string } }) {
  const product = getProductBySlug(params.slug);
  if (!product || product.inventoryStatus === "Draft" || product.inventoryStatus === "Archived") {
    notFound();
  }
  return <ProductDetailContent product={product} />;
}
