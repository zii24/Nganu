"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useCart } from "@/context/CartContext";
import { PRODUCTS } from "@/lib/mock-data";
import { isPurchasable } from "@/lib/utils";
import { getRegionById } from "@/lib/mock-shipping";
import { saveOrder, generateOrderId } from "@/lib/order-store";
import type { Order } from "@/lib/types";
import { CheckoutSteps } from "@/components/checkout/CheckoutSteps";
import { ShippingForm, type ShippingAddress } from "@/components/checkout/ShippingForm";
import { PaymentForm, type PaymentMethod } from "@/components/checkout/PaymentForm";
import { OrderSummary } from "@/components/checkout/OrderSummary";
import { Button, buttonVariants } from "@/components/ui/button";
import { EmptyState } from "@/components/shared/EmptyState";
import { ShoppingBag } from "lucide-react";

const EMPTY_ADDRESS: ShippingAddress = {
  fullName: "",
  phone: "",
  regionId: "id",
  address: "",
  city: "",
  province: "",
  postalCode: "",
  saveAddress: false,
};

export default function CheckoutPage() {
  const { ids, clear, hydrated } = useCart();
  const router = useRouter();

  const [step, setStep] = useState(0);
  const [address, setAddress] = useState<ShippingAddress>(EMPTY_ADDRESS);
  const [payment, setPayment] = useState<PaymentMethod>("virtual_account");
  const [placing, setPlacing] = useState(false);

  const items = ids
    .map((id) => PRODUCTS.find((p) => p.id === id))
    .filter((p): p is NonNullable<typeof p> => Boolean(p) && isPurchasable(p.inventoryStatus));

  if (hydrated && items.length === 0) {
    return (
      <div className="container py-16">
        <EmptyState
          icon={ShoppingBag}
          title="Nothing to check out"
          description="Add a piece to your cart first."
          action={
            <Link href="/shop" className={buttonVariants({})}>
              Continue Shopping
            </Link>
          }
        />
      </div>
    );
  }

  const addressValid =
    address.fullName.trim() && address.phone.trim() && address.address.trim() && address.city.trim() && address.province.trim() && address.postalCode.trim();

  function handlePlaceOrder() {
    setPlacing(true);
    const region = getRegionById(address.regionId)!;
    const totalIdr = items.reduce((sum, p) => sum + p.priceIdr, 0) + region.feeIdr;
    const totalUsd = items.reduce((sum, p) => sum + p.priceUsd, 0) + region.feeUsd;
    const now = new Date().toISOString();

    const order: Order = {
      id: generateOrderId(),
      items: items.map((p) => ({
        productId: p.id,
        name: p.name,
        slug: p.slug,
        image: (p.images.find((i) => i.kind === "front") ?? p.images[0]).url,
        priceIdr: p.priceIdr,
        priceUsd: p.priceUsd,
        size: p.size,
        quantity: 1,
      })),
      status: "Order Confirmed",
      timeline: [{ status: "Order Confirmed", timestamp: now, note: `Payment method: ${payment.replace("_", " ")}` }],
      shippingRegionId: region.id,
      shippingFeeIdr: region.feeIdr,
      shippingFeeUsd: region.feeUsd,
      totalIdr,
      totalUsd,
      createdAt: now,
    };

    saveOrder(order);
    clear();
    router.push(`/order/${order.id}`);
  }

  return (
    <div className="container py-8 lg:py-10">
      <h1 className="mb-2 text-2xl font-medium tracking-tight sm:text-[28px]">Checkout</h1>
      <CheckoutSteps current={step} />

      <div className="grid grid-cols-1 gap-10 lg:grid-cols-[1fr_380px]">
        <div>
          {step === 0 && (
            <div>
              <h2 className="mb-5 text-lg font-medium">Shipping Address</h2>
              <ShippingForm value={address} onChange={setAddress} />
              <Button className="mt-7 w-full sm:w-auto" disabled={!addressValid} onClick={() => setStep(1)}>
                Continue to Payment
              </Button>
            </div>
          )}

          {step === 1 && (
            <div>
              <h2 className="mb-5 text-lg font-medium">Payment Method</h2>
              <PaymentForm value={payment} onChange={setPayment} />
              <div className="mt-7 flex gap-3">
                <Button variant="outline" onClick={() => setStep(0)}>
                  Back
                </Button>
                <Button onClick={() => setStep(2)}>Review Order</Button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div>
              <h2 className="mb-5 text-lg font-medium">Confirm Your Order</h2>

              <div className="space-y-5">
                <div className="border border-border p-4">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium">Shipping to</p>
                    <button onClick={() => setStep(0)} className="text-xs text-primary hover:underline">
                      Edit
                    </button>
                  </div>
                  <p className="mt-1.5 text-sm text-muted-foreground">
                    {address.fullName} · {address.phone}
                    <br />
                    {address.address}, {address.city}, {address.province} {address.postalCode}
                    <br />
                    {getRegionById(address.regionId)?.name}
                  </p>
                </div>

                <div className="border border-border p-4">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium">Payment method</p>
                    <button onClick={() => setStep(1)} className="text-xs text-primary hover:underline">
                      Edit
                    </button>
                  </div>
                  <p className="mt-1.5 text-sm capitalize text-muted-foreground">{payment.replace("_", " ")}</p>
                </div>
              </div>

              <Button className="mt-7 w-full sm:w-auto" onClick={handlePlaceOrder} disabled={placing}>
                {placing ? "Placing Order…" : "Place Order"}
              </Button>
              <p className="mt-3 text-xs text-muted-foreground">
                By placing this order you agree to XFY's Buyer Protection terms. No real payment will be charged in
                this demo.
              </p>
            </div>
          )}
        </div>

        <OrderSummary items={items} regionId={address.regionId} />
      </div>
    </div>
  );
}
