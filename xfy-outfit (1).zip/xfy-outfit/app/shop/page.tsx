import { Suspense } from "react";
import { ShopContent } from "@/components/shop/ShopContent";
import { Skeleton } from "@/components/ui/skeleton";

export const metadata = {
  title: "Shop — XFY Outfit",
};

export default function ShopPage() {
  return (
    <Suspense fallback={<ShopSkeleton />}>
      <ShopContent />
    </Suspense>
  );
}

function ShopSkeleton() {
  return (
    <div className="container py-10">
      <Skeleton className="mb-7 h-8 w-40" />
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <Skeleton key={i} className="aspect-[4/5] w-full" />
        ))}
      </div>
    </div>
  );
}
