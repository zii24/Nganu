"use client";

import { CurrencyProvider } from "@/context/CurrencyContext";
import { LanguageProvider } from "@/context/LanguageContext";
import { WishlistProvider } from "@/context/WishlistContext";
import { RecentlyViewedProvider } from "@/context/RecentlyViewedContext";
import { CartProvider } from "@/context/CartContext";

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <LanguageProvider>
      <CurrencyProvider>
        <WishlistProvider>
          <RecentlyViewedProvider>
            <CartProvider>{children}</CartProvider>
          </RecentlyViewedProvider>
        </WishlistProvider>
      </CurrencyProvider>
    </LanguageProvider>
  );
}
