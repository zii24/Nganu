"use client";

import { createContext, useContext, useMemo, useCallback } from "react";
import { useLocalStorage } from "@/lib/use-local-storage";

interface CartContextValue {
  ids: string[];
  hydrated: boolean;
  has: (id: string) => boolean;
  add: (id: string) => void;
  remove: (id: string) => void;
  clear: () => void;
}

const CartContext = createContext<CartContextValue | null>(null);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [ids, setIds, hydrated] = useLocalStorage<string[]>("xfy_cart", []);

  const has = useCallback((id: string) => ids.includes(id), [ids]);

  const add = useCallback(
    (id: string) => {
      // One-of-one inventory: adding an item already in the cart is a no-op,
      // there is no quantity to increment.
      setIds((prev) => (prev.includes(id) ? prev : [...prev, id]));
    },
    [setIds]
  );

  const remove = useCallback(
    (id: string) => {
      setIds((prev) => prev.filter((x) => x !== id));
    },
    [setIds]
  );

  const clear = useCallback(() => setIds([]), [setIds]);

  const value = useMemo(
    () => ({ ids, hydrated, has, add, remove, clear }),
    [ids, hydrated, has, add, remove, clear]
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
}
