"use client";

import { createContext, useContext, useMemo, useCallback } from "react";
import { useLocalStorage } from "@/lib/use-local-storage";

const MAX_ITEMS = 8;

interface RecentlyViewedContextValue {
  ids: string[];
  hydrated: boolean;
  record: (id: string) => void;
}

const RecentlyViewedContext = createContext<RecentlyViewedContextValue | null>(null);

export function RecentlyViewedProvider({ children }: { children: React.ReactNode }) {
  const [ids, setIds, hydrated] = useLocalStorage<string[]>("xfy_recently_viewed", []);

  const record = useCallback(
    (id: string) => {
      setIds((prev) => [id, ...prev.filter((x) => x !== id)].slice(0, MAX_ITEMS));
    },
    [setIds]
  );

  const value = useMemo(() => ({ ids, hydrated, record }), [ids, hydrated, record]);

  return <RecentlyViewedContext.Provider value={value}>{children}</RecentlyViewedContext.Provider>;
}

export function useRecentlyViewed() {
  const ctx = useContext(RecentlyViewedContext);
  if (!ctx) throw new Error("useRecentlyViewed must be used within RecentlyViewedProvider");
  return ctx;
}
